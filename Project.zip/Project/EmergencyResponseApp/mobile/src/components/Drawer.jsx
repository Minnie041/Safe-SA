import { useCallback } from "react";
import {
  Animated,
  TouchableOpacity,
  View,
  Text,
  ScrollView,
  Dimensions,
  StyleSheet,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import {
  Home,
  Map,
  Shield,
  Clock,
  User,
  Users,
  Heart,
  Lightbulb,
  MapPin,
  LogOut,
  X,
  ChevronRight,
  Bell,
  AlertTriangle,
} from "lucide-react-native";
import { useDrawer } from "@/utils/DrawerContext";
import { useAuth } from "@/utils/auth/useAuth";
import useUser from "@/utils/auth/useUser";

const { height } = Dimensions.get("window");

const NAV_ITEMS = [
  {
    label: "Home Dashboard",
    icon: Home,
    route: "/(tabs)/home",
    color: "#2563EB",
  },
  { label: "Live Map", icon: Map, route: "/(tabs)/map", color: "#059669" },
  {
    label: "My Guardians",
    icon: Users,
    route: "/(tabs)/guardians",
    color: "#7C3AED",
  },
  {
    label: "Incident History",
    icon: Clock,
    route: "/(tabs)/history",
    color: "#D97706",
  },
  {
    label: "Medical Profile",
    icon: Heart,
    route: "/(tabs)/profile",
    color: "#DC2626",
  },
  {
    label: "Safety Tips",
    icon: Lightbulb,
    route: "/(tabs)/safety",
    color: "#0891B2",
  },
];

export default function Drawer() {
  const { isOpen, closeDrawer, translateX, DRAWER_WIDTH } = useDrawer();
  const router = useRouter();
  const { signOut } = useAuth();
  const { data: user } = useUser();

  const handleNav = useCallback(
    (route) => {
      closeDrawer();
      setTimeout(() => router.push(route), 250);
    },
    [closeDrawer, router],
  );

  const handleSignOut = useCallback(() => {
    closeDrawer();
    setTimeout(() => signOut(), 300);
  }, [closeDrawer, signOut]);

  if (!isOpen) return null;

  const initials = user?.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : (user?.email?.[0] || "S").toUpperCase();

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      {/* Backdrop */}
      <TouchableOpacity
        activeOpacity={1}
        onPress={closeDrawer}
        style={[
          StyleSheet.absoluteFill,
          { backgroundColor: "rgba(0,0,0,0.55)" },
        ]}
      />
      {/* Drawer Panel */}
      <Animated.View
        style={[
          styles.panel,
          { width: DRAWER_WIDTH, transform: [{ translateX }] },
        ]}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoRow}>
            <View style={styles.logoBadge}>
              <Text style={styles.logoText}>S</Text>
            </View>
            <View>
              <Text style={styles.appName}>SafeSA</Text>
              <Text style={styles.appTagline}>Emergency Response</Text>
            </View>
          </View>
          <TouchableOpacity onPress={closeDrawer} style={styles.closeBtn}>
            <X size={18} color="#9CA3AF" />
          </TouchableOpacity>
        </View>

        {/* User Profile Section */}
        {user && (
          <View style={styles.profileCard}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{initials}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.userName} numberOfLines={1}>
                {user.name || "SafeSA User"}
              </Text>
              <Text style={styles.userEmail} numberOfLines={1}>
                {user.email}
              </Text>
              <View style={styles.popiaBadge}>
                <Shield size={9} color="#059669" />
                <Text style={styles.popiaText}>POPIA Compliant</Text>
              </View>
            </View>
          </View>
        )}

        {/* Navigation */}
        <ScrollView
          style={styles.navScroll}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.sectionLabel}>NAVIGATION</Text>
          {NAV_ITEMS.map((item) => (
            <TouchableOpacity
              key={item.route}
              style={styles.navItem}
              onPress={() => handleNav(item.route)}
              activeOpacity={0.7}
            >
              <View
                style={[styles.navIcon, { backgroundColor: item.color + "18" }]}
              >
                <item.icon size={18} color={item.color} />
              </View>
              <Text style={styles.navLabel}>{item.label}</Text>
              <ChevronRight size={14} color="#9CA3AF" />
            </TouchableOpacity>
          ))}

          <View style={styles.divider} />
          <Text style={styles.sectionLabel}>EMERGENCY</Text>

          <TouchableOpacity
            style={styles.sosNavItem}
            onPress={() => handleNav("/(tabs)/home")}
            activeOpacity={0.8}
          >
            <View style={[styles.navIcon, { backgroundColor: "#FEE2E2" }]}>
              <AlertTriangle size={18} color="#DC2626" />
            </View>
            <Text
              style={[styles.navLabel, { color: "#DC2626", fontWeight: "700" }]}
            >
              SOS Emergency
            </Text>
          </TouchableOpacity>

          <View style={styles.saNumbers}>
            <Text style={styles.saTitle}>🇿🇦 SA Emergency Numbers</Text>
            {[
              ["Police", "10111"],
              ["Ambulance", "10177"],
              ["Fire", "10177"],
              ["Emergency", "112"],
            ].map(([label, num]) => (
              <View key={label} style={styles.numRow}>
                <Text style={styles.numLabel}>{label}</Text>
                <Text style={styles.numValue}>{num}</Text>
              </View>
            ))}
          </View>

          <View style={styles.divider} />

          <TouchableOpacity
            style={styles.signOutBtn}
            onPress={handleSignOut}
            activeOpacity={0.7}
          >
            <LogOut size={16} color="#EF4444" />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        </ScrollView>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            SafeSA v1.0 · Protected by POPIA
          </Text>
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    backgroundColor: "#0A0F1E",
    shadowColor: "#000",
    shadowOffset: { width: 4, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 20,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: Platform.OS === "ios" ? 56 : 40,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#1F2937",
  },
  logoRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  logoBadge: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: "#DC2626",
    alignItems: "center",
    justifyContent: "center",
  },
  logoText: { color: "#fff", fontSize: 18, fontWeight: "900" },
  appName: { color: "#F9FAFB", fontSize: 16, fontWeight: "800" },
  appTagline: { color: "#6B7280", fontSize: 10, fontWeight: "500" },
  closeBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: "#1F2937",
    alignItems: "center",
    justifyContent: "center",
  },
  profileCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    margin: 16,
    padding: 14,
    borderRadius: 14,
    backgroundColor: "#111827",
    borderWidth: 1,
    borderColor: "#1F2937",
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#2563EB",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: { color: "#fff", fontSize: 16, fontWeight: "800" },
  userName: { color: "#F9FAFB", fontSize: 14, fontWeight: "700" },
  userEmail: { color: "#6B7280", fontSize: 11, marginTop: 1 },
  popiaBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    marginTop: 4,
    backgroundColor: "#064E3B",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: "flex-start",
  },
  popiaText: { color: "#34D399", fontSize: 9, fontWeight: "700" },
  navScroll: { flex: 1, paddingHorizontal: 12 },
  sectionLabel: {
    color: "#4B5563",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.2,
    marginTop: 16,
    marginBottom: 6,
    paddingHorizontal: 8,
  },
  navItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 10,
    marginBottom: 2,
  },
  navIcon: {
    width: 34,
    height: 34,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  navLabel: { flex: 1, color: "#D1D5DB", fontSize: 14, fontWeight: "600" },
  sosNavItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 10,
    marginBottom: 2,
    backgroundColor: "#1F0707",
  },
  saNumbers: {
    margin: 8,
    padding: 12,
    borderRadius: 12,
    backgroundColor: "#111827",
    borderWidth: 1,
    borderColor: "#1F2937",
  },
  saTitle: {
    color: "#9CA3AF",
    fontSize: 11,
    fontWeight: "700",
    marginBottom: 8,
  },
  numRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 3,
  },
  numLabel: { color: "#6B7280", fontSize: 12 },
  numValue: { color: "#F9FAFB", fontSize: 12, fontWeight: "700" },
  divider: { height: 1, backgroundColor: "#1F2937", marginVertical: 10 },
  signOutBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 12,
    marginBottom: 20,
    borderRadius: 10,
    backgroundColor: "#1F0707",
  },
  signOutText: { color: "#EF4444", fontSize: 14, fontWeight: "600" },
  footer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: "#1F2937",
    alignItems: "center",
  },
  footerText: { color: "#374151", fontSize: 10 },
});
