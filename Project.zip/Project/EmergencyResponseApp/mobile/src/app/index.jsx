import { Redirect } from "expo-router";
import { useAuth } from "@/utils/auth/useAuth";

export default function Index() {
  const { user } = useAuth();

  // If user is not logged in, we might need to show a login/signup screen
  // But for now, we redirect to tabs. The auth wrapper usually handles session.
  return <Redirect href="/(tabs)/home" />;
}
