import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { HELP_CENTERS } from '../../utils/helpCenters'; // Using your existing file

export default function AdminLogin() {
  const [adminKey, setAdminKey] = useState('');
  const router = useRouter();

  const handleLogin = () => {
    // Check if the key matches any of our hardcoded help centers
    const center = HELP_CENTERS.find(c => c.id === adminKey);

    if (center) {
      // If found, go to dashboard and tell the dashboard WHICH center is logged in
      router.push({
        pathname: '/admin/dashboard',
        params: { centerId: center.id, centerName: center.name }
      });
    } else {
      Alert.alert("Invalid Key", "Please enter a valid Help Center ID.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Help Center Access</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Center ID (e.g., hosp_01)"
        value={adminKey}
        onChangeText={setAdminKey}
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login to Dashboard</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 15, borderRadius: 8, marginBottom: 20 },
  button: { backgroundColor: '#D32F2F', padding: 15, borderRadius: 8, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: 'bold' }
});