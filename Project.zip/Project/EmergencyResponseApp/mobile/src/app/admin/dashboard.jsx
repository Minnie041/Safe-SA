import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, SafeAreaView } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { db } from '../../utils/firebase'; // The file we just made
import { collection, query, where, onSnapshot } from 'firebase/firestore';

export default function AdminDashboard() {
  const { centerId, centerName } = useLocalSearchParams();
  const [incidents, setIncidents] = useState([]);

  useEffect(() => {
    // This looks at the 'incidents' collection in Firebase
    // It only grabs reports where 'assignedTo' matches the logged-in center ID
    const q = query(
      collection(db, "incidents"),
      where("assignedTo", "==", centerId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = [];
      snapshot.forEach((doc) => {
        docs.push({ id: doc.id, ...doc.data() });
      });
      setIncidents(docs); // Updates the list instantly when a user hits SOS
    });

    return () => unsubscribe();
  }, [centerId]);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>{centerName} Dashboard</Text>
      <FlatList
        data={incidents}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.name}>{item.userName} {item.userSurname}</Text>
            <Text>📍 {item.locationName}</Text>
            <View style={styles.medBox}>
              <Text style={{fontWeight: 'bold'}}>Medical Info:</Text>
              <Text>Blood: {item.medicalInfo?.bloodType}</Text>
              <Text>Allergies: {item.medicalInfo?.allergies}</Text>
            </View>
          </View>
        )}
      />
    </SafeAreaView>
  );
}
