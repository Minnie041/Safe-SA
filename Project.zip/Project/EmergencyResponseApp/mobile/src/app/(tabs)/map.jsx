import React, { useState, useEffect, useRef } from "react";
import { View, Text, TouchableOpacity, StyleSheet, TextInput, ActivityIndicator, Dimensions } from "react-native";
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from "react-native-maps";
import * as Location from "expo-location";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Menu, Shield, Flame, Phone, Car, Footprints, Bus, Navigation, X, Layers, Map as MapIcon } from "lucide-react-native";

// ICON CONFIG FOR HELP ZONES
const ZONE_ICONS = {
  police: { icon: Shield, color: "#1D4ED8" },
  hospital: { icon: Phone, color: "#B91C1C" },
  fire: { icon: Flame, color: "#B45309" },
  default: { icon: Navigation, color: "#3B82F6" }
};

export default function MapScreen() {
  const insets = useSafeAreaInsets();
  const mapRef = useRef(null);
  
  const [location, setLocation] = useState(null);
  const [mapType, setMapType] = useState('standard');
  const [travelMode, setTravelMode] = useState('driving');
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [routeInfo, setRouteInfo] = useState({ duration: "", distance: "", coords: [] });

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      let loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setLocation(loc);
    })();
  }, []);

  // 1. AUTOMATIC SEARCH & LOCATION LOGIC
  const handleSearch = async (text) => {
    setSearchQuery(text);
    if (text.length > 5) {
      const apiKey = "YOUR_GOOGLE_API_KEY";
      const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${text}&key=${apiKey}`;
      
      try {
        const res = await fetch(url);
        const data = await res.json();
        if (data.results.length > 0) {
          const place = data.results[0];
          const newLocation = {
            latitude: place.geometry.location.lat,
            longitude: place.geometry.location.lng,
            name: place.name,
            address: place.formatted_address,
            type: place.types.includes('police') ? 'police' : place.types.includes('hospital') ? 'hospital' : 'default'
          };
          
          // Smoothly move map to the searched area
          mapRef.current?.animateToRegion({
            ...newLocation,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          }, 1000);
          
          setSelectedPlace(newLocation);
          calculateRoute(newLocation, travelMode);
        }
      } catch (e) { console.error(e); }
    }
  };

  // 2. FUNCTIONAL TRANSPORT ICONS
  const calculateRoute = async (target, mode = travelMode) => {
    if (!location || !target) return;
    setTravelMode(mode);
    
    const origin = `${location.coords.latitude},${location.coords.longitude}`;
    const destination = `${target.latitude},${target.longitude}`;
    const apiKey = "YOUR_GOOGLE_API_KEY";
    const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${destination}&mode=${mode}&key=${apiKey}`;

    try {
      const res = await fetch(url);
      const data = await res.json();
      if (data.routes.length > 0) {
        const leg = data.routes[0].legs[0];
        setRouteInfo({
          duration: leg.duration.text,
          distance: leg.distance.text,
          coords: decodePolyline(data.routes[0].overview_polyline.points)
        });
      }
    } catch (e) { console.error(e); }
  };

  if (!location) return <ActivityIndicator size="large" style={styles.loader} />;

  return (
    <View style={{ flex: 1, backgroundColor: "#0A0F1E" }}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={StyleSheet.absoluteFillObject}
        mapType={mapType}
        showsUserLocation={true}
        initialRegion={{
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }}
      >
        {/* Automatic Marker for Selected/Searched Help Zone */}
        {selectedPlace && (
          <Marker coordinate={{ latitude: selectedPlace.latitude, longitude: selectedPlace.longitude }}>
            <View style={[styles.marker, { backgroundColor: (ZONE_ICONS[selectedPlace.type] || ZONE_ICONS.default).color }]}>
              {React.createElement((ZONE_ICONS[selectedPlace.type] || ZONE_ICONS.default).icon, { size: 16, color: "#FFF" })}
            </View>
          </Marker>
        )}

        {routeInfo.coords.length > 0 && (
          <Polyline coordinates={routeInfo.coords} strokeWidth={5} strokeColor="#3B82F6" />
        )}
      </MapView>

      {/* TOP: Search Bar & Transport Modes */}
      <View style={[styles.topOverlay, { top: insets.top + 10 }]}>
        <View style={styles.searchBar}>
          <Menu size={20} color="#9CA3AF" />
          <TextInput 
            value={searchQuery}
            onChangeText={handleSearch}
            placeholder="Search area (e.g. Berea)..." 
            placeholderTextColor="#9CA3AF" 
            style={styles.input} 
          />
        </View>

        <View style={styles.controlsRow}>
          <View style={styles.modeToggle}>
            <ModeBtn icon={Car} active={travelMode === 'driving'} onPress={() => calculateRoute(selectedPlace, 'driving')} />
            <ModeBtn icon={Footprints} active={travelMode === 'walking'} onPress={() => calculateRoute(selectedPlace, 'walking')} />
            <ModeBtn icon={Bus} active={travelMode === 'transit'} onPress={() => calculateRoute(selectedPlace, 'transit')} />
          </View>
          
          {/* Hybrid Toggle Design: Icon + Label Below */}
          <TouchableOpacity style={styles.hybridWrap} onPress={() => setMapType(mapType === 'standard' ? 'hybrid' : 'standard')}>
             <View style={styles.hybridIconBox}><Layers size={20} color="#FFF" /></View>
             <Text style={styles.hybridText}>Hybrid</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* REAL-TIME DIRECTION SHEET (Matching your uploaded examples) */}
      {selectedPlace && (
        <View style={[styles.detailCard, { paddingBottom: insets.bottom + 20 }]}>
          <Text style={styles.placeName}>{selectedPlace.name}</Text>
          <Text style={styles.placeSub}>{selectedPlace.address}</Text>

          <View style={styles.navStats}>
            <View style={styles.stat}>
              <Navigation size={18} color="#3B82F6" />
              <Text style={styles.statText}>{routeInfo.duration || "---"}</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statText}>{routeInfo.distance}</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.startBtn}>
            <Navigation size={22} color="#FFF" />
            <Text style={styles.startBtnText}>Start Directions</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

// Sub-components & Helper logic...
const ModeBtn = ({ icon: Icon, active, onPress }) => (
  <TouchableOpacity onPress={onPress} style={[styles.mBtn, active && styles.mBtnActive]}>
    <Icon size={22} color={active ? "#FFF" : "#9CA3AF"} />
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  loader: { flex: 1, backgroundColor: "#0A0F1E", justifyContent: "center" },
  topOverlay: { position: 'absolute', left: 16, right: 16, gap: 12 },
  searchBar: { flexDirection: 'row', backgroundColor: '#1E293BE6', padding: 14, borderRadius: 15, alignItems: 'center' },
  input: { flex: 1, color: '#FFF', marginLeft: 10 },
  controlsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  modeToggle: { flexDirection: 'row', gap: 10 },
  mBtn: { backgroundColor: '#1E293BE6', padding: 12, borderRadius: 14 },
  mBtnActive: { backgroundColor: '#3B82F6' },
  hybridWrap: { alignItems: 'center', gap: 4 },
  hybridIconBox: { backgroundColor: '#1E293BE6', padding: 12, borderRadius: 14 },
  hybridText: { color: '#FFF', fontSize: 10, fontWeight: 'bold', textTransform: 'uppercase' },
  marker: { padding: 8, borderRadius: 12, borderWidth: 2, borderColor: '#FFF' },
  detailCard: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#111827', borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 25 },
  placeName: { color: '#FFF', fontSize: 22, fontWeight: 'bold' },
  placeSub: { color: '#94A3B8', marginVertical: 5 },
  navStats: { flexDirection: 'row', gap: 15, marginVertical: 20 },
  stat: { flexDirection: 'row', gap: 8, backgroundColor: '#1F2937', padding: 10, borderRadius: 10, alignItems: 'center' },
  statText: { color: '#FFF', fontWeight: 'bold' },
  startBtn: { backgroundColor: '#3B82F6', flexDirection: 'row', padding: 18, borderRadius: 20, justifyContent: 'center', alignItems: 'center', gap: 10 },
  startBtnText: { color: '#FFF', fontSize: 18, fontWeight: 'bold' }
});

const decodePolyline = (t) => { /* logic remains same */ };