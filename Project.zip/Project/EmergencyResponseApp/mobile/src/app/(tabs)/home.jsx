import React, { useState, useCallback, useEffect, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Linking,
  Alert,
  ActivityIndicator,
  Animated,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Menu,
  Phone,
  Shield,
  Flame,
  MapPin,
  AlertTriangle,
  ChevronRight,
  Zap,
  Users,
  TrendingUp,
  PhoneCall,
} from "lucide-react-native";
import * as Location from "expo-location";
import * as Notifications from "expo-notifications";
import * as Haptics from "expo-haptics";
import { useAuth } from "@/utils/auth/useAuth";
import { useUser } from "@/utils/auth/useUser";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useDrawer } from "@/utils/DrawerContext";

// Firebase & Proximity Imports
import { db } from "../../utils/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { findNearestAdmin } from "../../utils/proximity";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

const EMERGENCY = [
  { label: "Police", number: "10111", icon: Shield, color: "#1D4ED8", bg: "#EFF6FF" },
  { label: "Ambulance", number: "10177", icon: Phone, color: "#059669", bg: "#ECFDF5" },
  { label: "Fire", number: "10177", icon: Flame, color: "#D97706", bg: "#FFFBEB" },
  { label: "Emergency", number: "112", icon: AlertTriangle, color: "#DC2626", bg: "#FEF2F2" },
];

function RiskBadge({ level }) {
  const map = {
    low: { bg: "#064E3B", text: "#34D399", label: "LOW RISK" },
    medium: { bg: "#451A03", text: "#FBBF24", label: "MED RISK" },
    high: { bg: "#450A0A", text: "#F87171", label: "HIGH RISK" },
  };
  const s = map[level] || map.low;
  return (
    <View style={{ backgroundColor: s.bg, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 }}>
      <Text style={{ color: s.text, fontSize: 10, fontWeight: "800" }}>{s.label}</Text>
    </View>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { isAuthenticated, signIn } = useAuth();
  const { data: user } = useUser();
  const { openDrawer } = useDrawer();
  const queryClient = useQueryClient();
  const [location, setLocation] = useState(null);
  const [address, setAddress] = useState(null);
  const [sosActive, setSosActive] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const pulseOpacity = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.parallel([
          Animated.timing(pulseAnim, { toValue: 1.18, duration: 900, useNativeDriver: true }),
          Animated.timing(pulseOpacity, { toValue: 0, duration: 900, useNativeDriver: true }),
        ]),
        Animated.parallel([
          Animated.timing(pulseAnim, { toValue: 1, duration: 0, useNativeDriver: true }),
          Animated.timing(pulseOpacity, { toValue: 0.6, duration: 0, useNativeDriver: true }),
        ]),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, []);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") return;
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setLocation(loc.coords);
      try {
        const rev = await Location.reverseGeocodeAsync(loc.coords);
        if (rev[0]) {
          const r = rev[0];
          setAddress(`${r.street || ""} ${r.city || r.subregion || ""}`.trim());
        }
      } catch (e) {}
    })();
  }, []);

  // Stats query
  const { data: stats } = useQuery({
    queryKey: ["stats", user?.id],
    queryFn: async () => {
      if (!user?.id) return { totalIncidents: 0, totalGuardians: 0 };
      const res = await fetch(`/api/emergency/stats?userId=${user.id}`);
      return res.json();
    },
    enabled: !!user?.id,
  });

  // Risk query
  const { data: risk } = useQuery({
    queryKey: ["risk", user?.id, location?.latitude],
    queryFn: async () => {
      if (!user?.id || !location) return null;
      const res = await fetch(`/api/emergency/risk?userId=${user.id}&latitude=${location.latitude}&longitude=${location.longitude}`);
      return res.json();
    },
    enabled: !!user?.id && !!location,
    refetchInterval: 60000,
  });

  // --- SOS Mutation (FIREBASE INTEGRATED) ---
  const sosMutation = useMutation({
    mutationFn: async ({ latitude, longitude }) => {
      // 1. Find the nearest Admin center
      const nearest = findNearestAdmin(latitude, longitude);

      // 2. Upload the SOS package to Firebase Firestore
      const docRef = await addDoc(collection(db, "incidents"), {
        userId: user?.id || "anonymous",
        userName: user?.name || "Slindokuhle",
        userSurname: "Nyawuza",
        locationName: address || "Durban Area",
        coords: { latitude, longitude },
        medicalInfo: {
          bloodType: "O+", 
          allergies: "None",
          conditions: "None",
        },
        assignedTo: nearest.id, // This is what the Admin Dashboard listens for
        status: "active",
        createdAt: serverTimestamp(),
      });

      return { id: docRef.id, centerName: nearest.name };
    },
    onSuccess: async (data) => {
      setSosActive(true);
      queryClient.invalidateQueries(["stats", user?.id]);
      
      Alert.alert(
        "🚨 SOS Alert Sent",
        `Emergency services at ${data.centerName} have been notified.\n\nStay calm. Help is on the way.`,
        [
          { text: "Cancel Alert", style: "destructive", onPress: () => setSosActive(false) },
          { text: "OK" },
        ]
      );
    },
    onError: () => Alert.alert("Error", "Could not send SOS. Check connection."),
  });

  const triggerSOS = useCallback(async () => {
    if (!isAuthenticated) {
      signIn();
      return;
    }
    if (Platform.OS !== "web") await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    
    Alert.alert(
      "⚠️ Confirm SOS Alert",
      "This will alert the nearest emergency services. Only use in a real emergency.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "🚨 SEND SOS NOW",
          style: "destructive",
          onPress: async () => {
            let coords = location;
            if (!coords) {
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status !== "granted") return;
              const loc = await Location.getCurrentPositionAsync({});
              coords = loc.coords;
              setLocation(coords);
            }
            sosMutation.mutate({ latitude: coords.latitude, longitude: coords.longitude });
          },
        },
      ]
    );
  }, [isAuthenticated, location, sosMutation, signIn]);

  const riskLevel = risk?.riskLevel || "low";
  const riskScore = risk?.riskScore || 0;
  const riskColors = { low: "#10B981", medium: "#F59E0B", high: "#EF4444" };
  const firstName = user?.name?.split(" ")[0] || "User";

  return (
    <View style={{ flex: 1, backgroundColor: "#0A0F1E" }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}>
        {/* Header Section */}
        <View style={{ paddingTop: insets.top + 8, paddingHorizontal: 20, paddingBottom: 20 }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <TouchableOpacity onPress={openDrawer} style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#111827", alignItems: "center", justifyContent: "center" }}>
              <Menu size={20} color="#9CA3AF" />
            </TouchableOpacity>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <View style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: "#DC2626", alignItems: "center", justifyContent: "center" }}>
                <Text style={{ color: "#fff", fontWeight: "900", fontSize: 14 }}>S</Text>
              </View>
              <Text style={{ color: "#F9FAFB", fontWeight: "800", fontSize: 16 }}>SafeSA</Text>
            </View>
            <RiskBadge level={riskLevel} />
          </View>
          <Text style={{ color: "#6B7280", fontSize: 12, fontWeight: "600" }}>WELCOME BACK</Text>
          <Text style={{ color: "#F9FAFB", fontSize: 22, fontWeight: "800", marginTop: 2 }}>{firstName} 👋</Text>
        </View>

        {/* SOS Button Section */}
        <View style={{ alignItems: "center", paddingVertical: 28, backgroundColor: sosActive ? "#1A0505" : "#0D1117", marginHorizontal: 20, borderRadius: 24, borderWidth: 1, borderColor: sosActive ? "#7F1D1D" : "#1F2937" }}>
          {sosActive && (
            <View style={{ backgroundColor: "#DC2626", paddingHorizontal: 14, paddingVertical: 4, borderRadius: 20, marginBottom: 14 }}>
              <Text style={{ color: "#fff", fontSize: 11, fontWeight: "800", letterSpacing: 1 }}>🚨 SOS ACTIVE — TRACKING LOCATION</Text>
            </View>
          )}
          
          <View style={{ width: 200, height: 200, alignItems: "center", justifyContent: "center" }}>
            <Animated.View style={{ position: "absolute", width: 200, height: 200, borderRadius: 100, backgroundColor: sosActive ? "#DC2626" : "#2563EB", transform: [{ scale: pulseAnim }], opacity: pulseOpacity }} />
            <TouchableOpacity onPress={triggerSOS} disabled={sosMutation.isPending} activeOpacity={0.85} style={{ width: 160, height: 160, borderRadius: 80, backgroundColor: sosActive ? "#DC2626" : "#2563EB", alignItems: "center", justifyContent: "center", borderWidth: 4, borderColor: sosActive ? "#F87171" : "#3B82F6" }}>
              {sosMutation.isPending ? <ActivityIndicator color="#fff" size="large" /> : (
                <View style={{ alignItems: "center" }}>
                  <AlertTriangle size={32} color="#fff" />
                  <Text style={{ color: "#fff", fontSize: 28, fontWeight: "900", letterSpacing: 2, marginTop: 4 }}>SOS</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* Location Display */}
        <View style={{ marginHorizontal: 20, marginTop: 12, backgroundColor: "#111827", padding: 12, borderRadius: 10, borderWidth: 1, borderColor: "#1F2937", flexDirection: "row", alignItems: "center", gap: 8 }}>
          <MapPin size={14} color="#10B981" />
          <Text style={{ color: "#9CA3AF", fontSize: 12, flex: 1 }} numberOfLines={1}>
            {address || (location ? `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}` : "Detecting location...")}
          </Text>
        </View>

        {/* Emergency Contacts Section */}
        <View style={{ marginHorizontal: 20, marginTop: 24 }}>
          <Text style={{ color: "#9CA3AF", fontSize: 10, fontWeight: "800", letterSpacing: 1, marginBottom: 12 }}>🇿🇦 NATIONAL EMERGENCY NUMBERS</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
            {EMERGENCY.map((item, i) => (
              <TouchableOpacity key={i} onPress={() => Linking.openURL(`tel:${item.number}`)} style={{ flex: 1, minWidth: "45%", backgroundColor: "#111827", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: "#1F2937", flexDirection: "row", alignItems: "center", gap: 10 }}>
                <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: item.bg, alignItems: "center", justifyContent: "center" }}>
                  <item.icon size={18} color={item.color} />
                </View>
                <View>
                  <Text style={{ color: "#F9FAFB", fontSize: 12, fontWeight: "700" }}>{item.label}</Text>
                  <Text style={{ color: "#DC2626", fontSize: 15, fontWeight: "900" }}>{item.number}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}