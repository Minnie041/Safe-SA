import React, { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Menu,
  Lightbulb,
  Shield,
  Car,
  Home,
  Phone,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  MapPin,
  Zap,
} from "lucide-react-native";
import { useDrawer } from "@/utils/DrawerContext";

const SAFETY_SECTIONS = [
  {
    id: 1,
    category: "Personal Safety",
    icon: Shield,
    color: "#2563EB",
    tips: [
      {
        title: "Stay Alert in Public",
        body: "Be aware of your surroundings at all times. Avoid using your phone while walking in busy areas. Trust your instincts — if something feels wrong, leave immediately.",
      },
      {
        title: "Travel in Groups",
        body: "Whenever possible, avoid traveling alone at night. Use well-lit, populated routes and inform someone of your travel plans and expected arrival time.",
      },
      {
        title: "Avoid Displaying Valuables",
        body: "Keep jewellery, phones, and laptops out of sight. Use discreet bags and keep important documents in a secure, hidden location.",
      },
      {
        title: "Share Your Location",
        body: "Use SafeSA's location sharing feature to keep guardians informed of your whereabouts, especially in unfamiliar areas or late at night.",
      },
    ],
  },
  {
    id: 2,
    category: "Vehicle Safety",
    icon: Car,
    color: "#D97706",
    tips: [
      {
        title: "Car Hijacking Prevention",
        body: "Keep car doors locked and windows closed in traffic. Be aware of vehicles following you. If threatened, surrender your vehicle — your life is worth more.",
      },
      {
        title: "Safe Parking",
        body: "Park in well-lit, busy areas. Avoid parking near vans or trucks that obstruct visibility. Check your surroundings before getting in or out of your vehicle.",
      },
      {
        title: "Traffic Light Safety",
        body: "At red lights, leave enough space to manoeuvre. Keep windows slightly raised. Avoid opening windows for strangers, no matter how convincing their story appears.",
      },
    ],
  },
  {
    id: 3,
    category: "Home Security",
    icon: Home,
    color: "#059669",
    tips: [
      {
        title: "Secure Entry Points",
        body: "Install quality locks, security gates, and an alarm system. Never leave spare keys outside. Change locks when moving into a new property.",
      },
      {
        title: "Neighbourhood Watch",
        body: "Get involved with local neighbourhood watch initiatives. Exchange contact details with trusted neighbours to create a community alert network.",
      },
      {
        title: "Electrical Safety",
        body: "Do not overload electrical circuits. Keep fire extinguishers accessible. Ensure your smoke detectors and CO detectors are tested monthly.",
      },
    ],
  },
  {
    id: 4,
    category: "Emergency Response",
    icon: Phone,
    color: "#DC2626",
    tips: [
      {
        title: "Know Your Emergency Numbers",
        body: "South African Police Service: 10111\nAmbulance & Medical: 10177\nFire Department: 10177\nGeneral Emergency: 112\nSANS Coast Guard: 021 938 3300",
      },
      {
        title: "SOS Protocol",
        body: "When activating SafeSA SOS: Stay calm, confirm your location, stay on the line with emergency services, and if safe to do so, alert someone nearby.",
      },
      {
        title: "Medical Emergency",
        body: "Keep first aid training up-to-date. Know the location of your nearest hospital and 24-hour clinic. Maintain a first aid kit at home and in your vehicle.",
      },
      {
        title: "Natural Disasters",
        body: "South Africa is prone to floods, veldfires, and severe storms. Follow SAWS weather alerts and local municipality emergency plans for your area.",
      },
    ],
  },
  {
    id: 5,
    category: "Digital Safety",
    icon: Zap,
    color: "#7C3AED",
    tips: [
      {
        title: "Protect Personal Data",
        body: "Under POPIA, your personal information must be collected, processed, and stored securely. Report any suspicious data use to the Information Regulator at complaints.IR@justice.gov.za.",
      },
      {
        title: "SIM Swapping Prevention",
        body: "Use strong PINs for your mobile account. Set up notifications for SIM changes. Immediately contact your carrier if you lose mobile service unexpectedly.",
      },
      {
        title: "Social Media Caution",
        body: "Never share your real-time location, daily routine, or absence from home on public social media. Criminals monitor social platforms to identify targets.",
      },
    ],
  },
  {
    id: 6,
    category: "High-Risk Areas",
    icon: MapPin,
    color: "#EF4444",
    tips: [
      {
        title: "AI Risk Assessment",
        body: "SafeSA uses your location history and area incident data to calculate a real-time risk score. Check the Home screen risk indicator before traveling to unfamiliar areas.",
      },
      {
        title: "Public Transport Safety",
        body: "In minibus taxis and buses, sit near the driver if possible. Keep your phone concealed. Be aware of exit points. Avoid late-night public transport when possible.",
      },
      {
        title: "ATM Safety",
        body: "Use indoor ATMs inside shopping centres. Be aware of people watching or standing close. Shield your PIN at all times. Never accept help from strangers at ATMs.",
      },
    ],
  },
];

function SafetyCard({ section }) {
  const [expanded, setExpanded] = useState(false);
  const [openTip, setOpenTip] = useState(null);

  return (
    <View
      style={{
        backgroundColor: "#111827",
        borderRadius: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: "#1F2937",
        overflow: "hidden",
      }}
    >
      <TouchableOpacity
        onPress={() => setExpanded((v) => !v)}
        activeOpacity={0.8}
        style={{
          padding: 16,
          flexDirection: "row",
          alignItems: "center",
          gap: 14,
        }}
      >
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 12,
            backgroundColor: section.color + "22",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <section.icon size={20} color={section.color} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: "#F9FAFB", fontWeight: "700", fontSize: 15 }}>
            {section.category}
          </Text>
          <Text style={{ color: "#6B7280", fontSize: 11, marginTop: 2 }}>
            {section.tips.length} safety guidelines
          </Text>
        </View>
        {expanded ? (
          <ChevronUp size={18} color="#6B7280" />
        ) : (
          <ChevronDown size={18} color="#6B7280" />
        )}
      </TouchableOpacity>

      {expanded && (
        <View style={{ borderTopWidth: 1, borderTopColor: "#1F2937" }}>
          {section.tips.map((tip, i) => (
            <View key={i}>
              <TouchableOpacity
                onPress={() => setOpenTip(openTip === i ? null : i)}
                activeOpacity={0.7}
                style={{
                  padding: 14,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 12,
                  borderBottomWidth:
                    i < section.tips.length - 1 || openTip === i ? 1 : 0,
                  borderBottomColor: "#1F2937",
                }}
              >
                <View
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: 3,
                    backgroundColor: section.color,
                    marginTop: 1,
                  }}
                />
                <Text
                  style={{
                    flex: 1,
                    color: "#D1D5DB",
                    fontWeight: "600",
                    fontSize: 13,
                  }}
                >
                  {tip.title}
                </Text>
                {openTip === i ? (
                  <ChevronUp size={14} color="#6B7280" />
                ) : (
                  <ChevronDown size={14} color="#6B7280" />
                )}
              </TouchableOpacity>
              {openTip === i && (
                <View
                  style={{
                    paddingHorizontal: 14,
                    paddingBottom: 14,
                    paddingTop: 4,
                    backgroundColor: "#0D1117",
                  }}
                >
                  <Text
                    style={{ color: "#9CA3AF", fontSize: 13, lineHeight: 20 }}
                  >
                    {tip.body}
                  </Text>
                </View>
              )}
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

export default function SafetyScreen() {
  const insets = useSafeAreaInsets();
  const { openDrawer } = useDrawer();

  return (
    <View style={{ flex: 1, backgroundColor: "#0A0F1E" }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 8,
            paddingHorizontal: 20,
            paddingBottom: 20,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 16,
            }}
          >
            <TouchableOpacity
              onPress={openDrawer}
              style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                backgroundColor: "#111827",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Menu size={20} color="#9CA3AF" />
            </TouchableOpacity>
            <Text style={{ color: "#F9FAFB", fontWeight: "800", fontSize: 18 }}>
              Safety Tips
            </Text>
            <View style={{ width: 40 }} />
          </View>

          {/* Banner */}
          <View
            style={{
              backgroundColor: "#0D1A0D",
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: "#1A3A1A",
              flexDirection: "row",
              gap: 14,
              alignItems: "flex-start",
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 12,
                backgroundColor: "#14532D",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Lightbulb size={20} color="#34D399" />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  color: "#34D399",
                  fontWeight: "800",
                  fontSize: 14,
                  marginBottom: 4,
                }}
              >
                South African Safety Guide
              </Text>
              <Text style={{ color: "#6B7280", fontSize: 12, lineHeight: 18 }}>
                Curated safety guidelines for everyday life in South Africa. Tap
                a category to expand, then tap a tip for full details.
              </Text>
            </View>
          </View>

          {/* Emergency Quick Ref */}
          <View
            style={{
              backgroundColor: "#1A0505",
              borderRadius: 14,
              padding: 14,
              marginTop: 14,
              borderWidth: 1,
              borderColor: "#7F1D1D",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                marginBottom: 10,
              }}
            >
              <AlertTriangle size={14} color="#EF4444" />
              <Text
                style={{
                  color: "#EF4444",
                  fontWeight: "800",
                  fontSize: 11,
                  letterSpacing: 0.5,
                }}
              >
                🇿🇦 EMERGENCY QUICK REFERENCE
              </Text>
            </View>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {[
                ["Police SAPS", "10111"],
                ["Ambulance", "10177"],
                ["Fire", "10177"],
                ["Emergency", "112"],
              ].map(([l, n]) => (
                <View
                  key={l}
                  style={{
                    backgroundColor: "#450A0A",
                    paddingHorizontal: 10,
                    paddingVertical: 6,
                    borderRadius: 8,
                    flexDirection: "row",
                    gap: 6,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#9CA3AF", fontSize: 11 }}>{l}:</Text>
                  <Text
                    style={{
                      color: "#F87171",
                      fontWeight: "900",
                      fontSize: 13,
                    }}
                  >
                    {n}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* Safety Sections */}
        <View style={{ paddingHorizontal: 20 }}>
          <Text
            style={{
              color: "#9CA3AF",
              fontSize: 10,
              fontWeight: "800",
              letterSpacing: 1,
              marginBottom: 14,
            }}
          >
            {SAFETY_SECTIONS.length} SAFETY CATEGORIES
          </Text>
          {SAFETY_SECTIONS.map((section) => (
            <SafetyCard key={section.id} section={section} />
          ))}

          {/* POPIA Footer */}
          <View
            style={{
              backgroundColor: "#0D1A0D",
              borderRadius: 14,
              padding: 14,
              borderWidth: 1,
              borderColor: "#1A3A1A",
              marginTop: 8,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                gap: 8,
                alignItems: "center",
                marginBottom: 6,
              }}
            >
              <Shield size={14} color="#34D399" />
              <Text
                style={{ color: "#34D399", fontWeight: "800", fontSize: 11 }}
              >
                POPIA NOTICE
              </Text>
            </View>
            <Text style={{ color: "#6B7280", fontSize: 11, lineHeight: 17 }}>
              SafeSA collects and processes personal data in accordance with the
              Protection of Personal Information Act (POPIA) 2013. For data
              inquiries: info@safesa.co.za | Information Regulator:
              complaints.IR@justice.gov.za
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
