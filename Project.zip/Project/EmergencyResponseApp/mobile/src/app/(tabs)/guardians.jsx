import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Linking,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import {
  Menu,
  Users,
  Plus,
  Phone,
  Mail,
  Trash2,
  UserCheck,
  ChevronDown,
  ChevronUp,
  X,
} from "lucide-react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useUser } from "@/utils/auth/useUser";
import { useAuth } from "@/utils/auth/useAuth";
import { useDrawer } from "@/utils/DrawerContext";

const RELATIONSHIPS = [
  "Parent",
  "Sibling",
  "Spouse",
  "Friend",
  "Colleague",
  "Doctor",
  "Other",
];

function GuardianCard({ guardian, onDelete }) {
  const initials = guardian.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
  const colors = ["#DC2626", "#2563EB", "#7C3AED", "#059669", "#D97706"];
  const color = colors[guardian.id % colors.length];

  return (
    <View
      style={{
        backgroundColor: "#111827",
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: "#1F2937",
        marginBottom: 12,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
        <View
          style={{
            width: 50,
            height: 50,
            borderRadius: 25,
            backgroundColor: color + "22",
            borderWidth: 2,
            borderColor: color,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text style={{ color: color, fontWeight: "900", fontSize: 16 }}>
            {initials}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: "#F9FAFB", fontWeight: "700", fontSize: 15 }}>
            {guardian.name}
          </Text>
          {guardian.relationship && (
            <Text
              style={{
                color: color,
                fontSize: 11,
                fontWeight: "700",
                marginTop: 2,
              }}
            >
              {guardian.relationship}
            </Text>
          )}
          <Text style={{ color: "#6B7280", fontSize: 12, marginTop: 3 }}>
            {guardian.phone}
          </Text>
          {guardian.email && (
            <Text style={{ color: "#4B5563", fontSize: 11 }}>
              {guardian.email}
            </Text>
          )}
        </View>
        <TouchableOpacity
          onPress={onDelete}
          style={{
            width: 36,
            height: 36,
            borderRadius: 10,
            backgroundColor: "#1F0707",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Trash2 size={16} color="#EF4444" />
        </TouchableOpacity>
      </View>
      <View style={{ flexDirection: "row", gap: 10, marginTop: 14 }}>
        <TouchableOpacity
          onPress={() => Linking.openURL(`tel:${guardian.phone}`)}
          style={{
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            backgroundColor: "#064E3B",
            borderRadius: 10,
            paddingVertical: 10,
          }}
        >
          <Phone size={15} color="#34D399" />
          <Text style={{ color: "#34D399", fontWeight: "700", fontSize: 13 }}>
            Call
          </Text>
        </TouchableOpacity>
        {guardian.email && (
          <TouchableOpacity
            onPress={() => Linking.openURL(`mailto:${guardian.email}`)}
            style={{
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              backgroundColor: "#1E3A5F",
              borderRadius: 10,
              paddingVertical: 10,
            }}
          >
            <Mail size={15} color="#60A5FA" />
            <Text style={{ color: "#60A5FA", fontWeight: "700", fontSize: 13 }}>
              Email
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

export default function GuardiansScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const { isAuthenticated, signIn } = useAuth();
  const { openDrawer } = useDrawer();
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [showRelPicker, setShowRelPicker] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    relationship: "",
  });

  const {
    data: guardians = [],
    isLoading,
    refetch,
    isFetching,
  } = useQuery({
    queryKey: ["guardians", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const res = await fetch(`/api/emergency/guardians?userId=${user.id}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!user?.id,
  });

  const addMutation = useMutation({
    mutationFn: async (data) => {
      const res = await fetch("/api/emergency/guardians", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id, ...data }),
      });
      if (!res.ok) throw new Error("Failed to add guardian");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["guardians", user?.id]);
      queryClient.invalidateQueries(["stats", user?.id]);
      setForm({ name: "", phone: "", email: "", relationship: "" });
      setShowForm(false);
    },
    onError: () =>
      Alert.alert("Error", "Could not add guardian. Check your connection."),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const res = await fetch(
        `/api/emergency/guardians?id=${id}&userId=${user.id}`,
        { method: "DELETE" },
      );
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["guardians", user?.id]);
      queryClient.invalidateQueries(["stats", user?.id]);
    },
    onError: () => Alert.alert("Error", "Could not remove guardian."),
  });

  const handleAdd = () => {
    if (!form.name.trim()) {
      Alert.alert("Required", "Please enter guardian name.");
      return;
    }
    if (!form.phone.trim()) {
      Alert.alert("Required", "Please enter phone number.");
      return;
    }
    addMutation.mutate(form);
  };

  const confirmDelete = (g) => {
    Alert.alert("Remove Guardian", `Remove ${g.name} as a guardian?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove",
        style: "destructive",
        onPress: () => deleteMutation.mutate(g.id),
      },
    ]);
  };

  if (!isAuthenticated) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0A0F1E",
          justifyContent: "center",
          alignItems: "center",
          padding: 32,
        }}
      >
        <Users size={48} color="#7C3AED" />
        <Text
          style={{
            color: "#F9FAFB",
            fontSize: 20,
            fontWeight: "800",
            marginTop: 16,
          }}
        >
          My Guardians
        </Text>
        <Text style={{ color: "#6B7280", textAlign: "center", marginTop: 8 }}>
          Sign in to manage your emergency guardians
        </Text>
        <TouchableOpacity
          onPress={signIn}
          style={{
            marginTop: 24,
            backgroundColor: "#DC2626",
            paddingHorizontal: 32,
            paddingVertical: 14,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: "#fff", fontWeight: "800" }}>Sign In</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#0A0F1E" }}>
      <KeyboardAvoidingAnimatedView behavior="padding" style={{ flex: 1 }}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
          refreshControl={
            <RefreshControl
              refreshing={isFetching}
              onRefresh={refetch}
              tintColor="#7C3AED"
            />
          }
        >
          {/* Header */}
          <View
            style={{
              paddingTop: insets.top + 8,
              paddingHorizontal: 20,
              paddingBottom: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 16,
              }}
            >
              <TouchableOpacity
                onPress={openDrawer}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 10,
                  backgroundColor: "#111827",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Menu size={20} color="#9CA3AF" />
              </TouchableOpacity>
              <Text
                style={{ color: "#F9FAFB", fontWeight: "800", fontSize: 18 }}
              >
                My Guardians
              </Text>
              <TouchableOpacity
                onPress={() => setShowForm((v) => !v)}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 10,
                  backgroundColor: "#7C3AED",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {showForm ? (
                  <X size={18} color="#fff" />
                ) : (
                  <Plus size={18} color="#fff" />
                )}
              </TouchableOpacity>
            </View>

            {/* Info Banner */}
            <View
              style={{
                backgroundColor: "#1E1B4B",
                borderRadius: 12,
                padding: 14,
                borderWidth: 1,
                borderColor: "#312E81",
                flexDirection: "row",
                gap: 12,
              }}
            >
              <UserCheck size={20} color="#818CF8" />
              <View style={{ flex: 1 }}>
                <Text
                  style={{ color: "#A5B4FC", fontWeight: "700", fontSize: 12 }}
                >
                  Guardian Network
                </Text>
                <Text
                  style={{
                    color: "#6B7280",
                    fontSize: 11,
                    marginTop: 3,
                    lineHeight: 16,
                  }}
                >
                  Guardians receive instant SOS alerts with your GPS location
                  and medical information during emergencies.
                </Text>
              </View>
            </View>
          </View>

          {/* Add Guardian Form */}
          {showForm && (
            <View
              style={{
                marginHorizontal: 20,
                marginBottom: 20,
                backgroundColor: "#111827",
                borderRadius: 16,
                padding: 18,
                borderWidth: 1,
                borderColor: "#312E81",
              }}
            >
              <Text
                style={{
                  color: "#A5B4FC",
                  fontSize: 12,
                  fontWeight: "800",
                  letterSpacing: 0.5,
                  marginBottom: 16,
                }}
              >
                ADD NEW GUARDIAN
              </Text>
              <View style={{ gap: 12 }}>
                <View>
                  <Text
                    style={{
                      color: "#9CA3AF",
                      fontSize: 11,
                      fontWeight: "600",
                      marginBottom: 5,
                    }}
                  >
                    FULL NAME *
                  </Text>
                  <TextInput
                    value={form.name}
                    onChangeText={(v) => setForm((p) => ({ ...p, name: v }))}
                    placeholder="Guardian's full name"
                    placeholderTextColor="#4B5563"
                    style={{
                      backgroundColor: "#0A0F1E",
                      borderWidth: 1,
                      borderColor: "#1F2937",
                      borderRadius: 10,
                      padding: 12,
                      color: "#F9FAFB",
                      fontSize: 14,
                    }}
                  />
                </View>
                <View>
                  <Text
                    style={{
                      color: "#9CA3AF",
                      fontSize: 11,
                      fontWeight: "600",
                      marginBottom: 5,
                    }}
                  >
                    PHONE NUMBER *
                  </Text>
                  <TextInput
                    value={form.phone}
                    onChangeText={(v) => setForm((p) => ({ ...p, phone: v }))}
                    placeholder="+27 82 000 0000"
                    placeholderTextColor="#4B5563"
                    keyboardType="phone-pad"
                    style={{
                      backgroundColor: "#0A0F1E",
                      borderWidth: 1,
                      borderColor: "#1F2937",
                      borderRadius: 10,
                      padding: 12,
                      color: "#F9FAFB",
                      fontSize: 14,
                    }}
                  />
                </View>
                <View>
                  <Text
                    style={{
                      color: "#9CA3AF",
                      fontSize: 11,
                      fontWeight: "600",
                      marginBottom: 5,
                    }}
                  >
                    EMAIL (FOR SOS NOTIFICATIONS)
                  </Text>
                  <TextInput
                    value={form.email}
                    onChangeText={(v) => setForm((p) => ({ ...p, email: v }))}
                    placeholder="guardian@email.com"
                    placeholderTextColor="#4B5563"
                    keyboardType="email-address"
                    style={{
                      backgroundColor: "#0A0F1E",
                      borderWidth: 1,
                      borderColor: "#1F2937",
                      borderRadius: 10,
                      padding: 12,
                      color: "#F9FAFB",
                      fontSize: 14,
                    }}
                  />
                </View>
                <View>
                  <Text
                    style={{
                      color: "#9CA3AF",
                      fontSize: 11,
                      fontWeight: "600",
                      marginBottom: 5,
                    }}
                  >
                    RELATIONSHIP
                  </Text>
                  <TouchableOpacity
                    onPress={() => setShowRelPicker((v) => !v)}
                    style={{
                      backgroundColor: "#0A0F1E",
                      borderWidth: 1,
                      borderColor: "#1F2937",
                      borderRadius: 10,
                      padding: 12,
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <Text
                      style={{
                        color: form.relationship ? "#F9FAFB" : "#4B5563",
                        fontSize: 14,
                      }}
                    >
                      {form.relationship || "Select relationship..."}
                    </Text>
                    {showRelPicker ? (
                      <ChevronUp size={16} color="#9CA3AF" />
                    ) : (
                      <ChevronDown size={16} color="#9CA3AF" />
                    )}
                  </TouchableOpacity>
                  {showRelPicker && (
                    <View
                      style={{
                        backgroundColor: "#0A0F1E",
                        borderWidth: 1,
                        borderColor: "#1F2937",
                        borderRadius: 10,
                        marginTop: 4,
                      }}
                    >
                      {RELATIONSHIPS.map((r) => (
                        <TouchableOpacity
                          key={r}
                          onPress={() => {
                            setForm((p) => ({ ...p, relationship: r }));
                            setShowRelPicker(false);
                          }}
                          style={{
                            padding: 12,
                            borderBottomWidth: 1,
                            borderBottomColor: "#1F2937",
                          }}
                        >
                          <Text
                            style={{
                              color:
                                form.relationship === r ? "#A5B4FC" : "#D1D5DB",
                              fontSize: 13,
                              fontWeight:
                                form.relationship === r ? "700" : "400",
                            }}
                          >
                            {r}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  )}
                </View>
                <TouchableOpacity
                  onPress={handleAdd}
                  disabled={addMutation.isPending}
                  style={{
                    backgroundColor: "#7C3AED",
                    borderRadius: 12,
                    padding: 14,
                    alignItems: "center",
                    flexDirection: "row",
                    justifyContent: "center",
                    gap: 8,
                  }}
                >
                  {addMutation.isPending ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <>
                      <Plus size={16} color="#fff" />
                      <Text
                        style={{
                          color: "#fff",
                          fontWeight: "800",
                          fontSize: 14,
                        }}
                      >
                        Add Guardian
                      </Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Guardian List */}
          <View style={{ paddingHorizontal: 20 }}>
            {isLoading ? (
              <View style={{ paddingTop: 40, alignItems: "center" }}>
                <ActivityIndicator color="#7C3AED" />
              </View>
            ) : guardians.length === 0 ? (
              <View style={{ paddingTop: 32, alignItems: "center" }}>
                <View
                  style={{
                    width: 72,
                    height: 72,
                    borderRadius: 36,
                    backgroundColor: "#1E1B4B",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 14,
                  }}
                >
                  <Users size={32} color="#7C3AED" />
                </View>
                <Text
                  style={{ color: "#F9FAFB", fontWeight: "700", fontSize: 16 }}
                >
                  No guardians yet
                </Text>
                <Text
                  style={{
                    color: "#6B7280",
                    textAlign: "center",
                    marginTop: 8,
                    fontSize: 13,
                  }}
                >
                  Add trusted people who will be notified instantly during
                  emergencies
                </Text>
                <TouchableOpacity
                  onPress={() => setShowForm(true)}
                  style={{
                    marginTop: 20,
                    backgroundColor: "#7C3AED",
                    paddingHorizontal: 24,
                    paddingVertical: 12,
                    borderRadius: 12,
                    flexDirection: "row",
                    gap: 8,
                    alignItems: "center",
                  }}
                >
                  <Plus size={16} color="#fff" />
                  <Text style={{ color: "#fff", fontWeight: "700" }}>
                    Add First Guardian
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <Text
                  style={{
                    color: "#9CA3AF",
                    fontSize: 10,
                    fontWeight: "800",
                    letterSpacing: 1,
                    marginBottom: 12,
                  }}
                >
                  {guardians.length} GUARDIAN{guardians.length !== 1 ? "S" : ""}{" "}
                  REGISTERED
                </Text>
                {guardians.map((g) => (
                  <GuardianCard
                    key={g.id}
                    guardian={g}
                    onDelete={() => confirmDelete(g)}
                  />
                ))}
              </>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingAnimatedView>
    </View>
  );
}
