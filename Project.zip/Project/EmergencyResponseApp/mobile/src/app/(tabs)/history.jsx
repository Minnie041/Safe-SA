import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Linking,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Menu,
  AlertTriangle,
  MapPin,
  Clock,
  CheckCircle,
  XCircle,
  Filter,
  ChevronRight,
} from "lucide-react-native";
import { useQuery } from "@tanstack/react-query";
import { useUser } from "@/utils/auth/useUser";
import { useAuth } from "@/utils/auth/useAuth";
import { useDrawer } from "@/utils/DrawerContext";

const RISK_STYLE = {
  high: { bg: "#450A0A", text: "#F87171", label: "HIGH" },
  medium: { bg: "#451A03", text: "#FBBF24", label: "MED" },
  low: { bg: "#064E3B", text: "#34D399", label: "LOW" },
};

const TYPE_STYLE = {
  sos: { bg: "#DC2626", icon: AlertTriangle, label: "SOS Alert" },
  incident: { bg: "#7C3AED", icon: MapPin, label: "Incident" },
  report: { bg: "#D97706", icon: Filter, label: "Report" },
};

function IncidentCard({ item, onMapPress }) {
  const risk = RISK_STYLE[item.risk_level] || RISK_STYLE.low;
  const type = TYPE_STYLE[item.type] || TYPE_STYLE.sos;
  const date = new Date(item.created_at);
  const isResolved = item.status === "resolved";

  return (
    <View
      style={{
        backgroundColor: "#111827",
        borderRadius: 14,
        padding: 16,
        borderWidth: 1,
        borderColor: "#1F2937",
        marginBottom: 12,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 12 }}>
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 10,
            backgroundColor: type.bg + "22",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <type.icon size={20} color={type.bg} />
        </View>
        <View style={{ flex: 1 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Text style={{ color: "#F9FAFB", fontWeight: "700", fontSize: 14 }}>
              {type.label}
            </Text>
            <View
              style={{
                backgroundColor: risk.bg,
                paddingHorizontal: 8,
                paddingVertical: 3,
                borderRadius: 6,
              }}
            >
              <Text
                style={{ color: risk.text, fontSize: 10, fontWeight: "800" }}
              >
                {risk.label} RISK
              </Text>
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 5,
              marginTop: 5,
            }}
          >
            <Clock size={11} color="#6B7280" />
            <Text style={{ color: "#6B7280", fontSize: 11 }}>
              {date.toLocaleDateString("en-ZA", {
                day: "2-digit",
                month: "short",
                year: "numeric",
              })}{" "}
              ·{" "}
              {date.toLocaleTimeString("en-ZA", {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </Text>
          </View>

          {item.latitude && item.longitude && (
            <TouchableOpacity
              onPress={() =>
                Linking.openURL(
                  `https://maps.google.com/?q=${item.latitude},${item.longitude}`,
                )
              }
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 5,
                marginTop: 6,
                backgroundColor: "#0D1117",
                padding: 7,
                borderRadius: 8,
              }}
            >
              <MapPin size={11} color="#4B7BEB" />
              <Text
                style={{ color: "#4B7BEB", fontSize: 11, fontWeight: "600" }}
              >
                {parseFloat(item.latitude).toFixed(5)},{" "}
                {parseFloat(item.longitude).toFixed(5)}
              </Text>
              <ChevronRight size={11} color="#4B7BEB" />
            </TouchableOpacity>
          )}

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
              marginTop: 10,
            }}
          >
            {isResolved ? (
              <>
                <CheckCircle size={13} color="#10B981" />
                <Text
                  style={{ color: "#10B981", fontSize: 12, fontWeight: "600" }}
                >
                  Resolved
                </Text>
              </>
            ) : (
              <>
                <XCircle size={13} color="#EF4444" />
                <Text
                  style={{ color: "#EF4444", fontSize: 12, fontWeight: "600" }}
                >
                  Active
                </Text>
              </>
            )}
          </View>
        </View>
      </View>
    </View>
  );
}

const FILTERS = ["All", "SOS", "Active", "Resolved"];

export default function HistoryScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const { isAuthenticated, signIn } = useAuth();
  const { openDrawer } = useDrawer();
  const [activeFilter, setActiveFilter] = useState("All");

  const {
    data: incidents = [],
    isLoading,
    refetch,
    isFetching,
  } = useQuery({
    queryKey: ["incidents", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const res = await fetch(
        `/api/emergency/incidents?userId=${user.id}&limit=100`,
      );
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!user?.id,
  });

  const filtered = incidents.filter((item) => {
    if (activeFilter === "SOS") return item.type === "sos";
    if (activeFilter === "Active") return item.status !== "resolved";
    if (activeFilter === "Resolved") return item.status === "resolved";
    return true;
  });

  const sosCnt = incidents.filter((i) => i.type === "sos").length;
  const activeCnt = incidents.filter((i) => i.status !== "resolved").length;

  if (!isAuthenticated) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0A0F1E",
          justifyContent: "center",
          alignItems: "center",
          padding: 32,
        }}
      >
        <Clock size={48} color="#DC2626" />
        <Text
          style={{
            color: "#F9FAFB",
            fontSize: 20,
            fontWeight: "800",
            marginTop: 16,
          }}
        >
          Incident History
        </Text>
        <Text style={{ color: "#6B7280", textAlign: "center", marginTop: 8 }}>
          Sign in to view your emergency history
        </Text>
        <TouchableOpacity
          onPress={signIn}
          style={{
            marginTop: 24,
            backgroundColor: "#DC2626",
            paddingHorizontal: 32,
            paddingVertical: 14,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: "#fff", fontWeight: "800" }}>Sign In</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#0A0F1E" }}>
      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 8,
          paddingHorizontal: 20,
          paddingBottom: 12,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 16,
          }}
        >
          <TouchableOpacity
            onPress={openDrawer}
            style={{
              width: 40,
              height: 40,
              borderRadius: 10,
              backgroundColor: "#111827",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Menu size={20} color="#9CA3AF" />
          </TouchableOpacity>
          <Text style={{ color: "#F9FAFB", fontWeight: "800", fontSize: 18 }}>
            Incident History
          </Text>
          <View style={{ width: 40 }} />
        </View>

        {/* Stats Row */}
        <View style={{ flexDirection: "row", gap: 10, marginBottom: 14 }}>
          {[
            { label: "Total", value: incidents.length, color: "#9CA3AF" },
            { label: "SOS Alerts", value: sosCnt, color: "#DC2626" },
            { label: "Active", value: activeCnt, color: "#F59E0B" },
          ].map((s) => (
            <View
              key={s.label}
              style={{
                flex: 1,
                backgroundColor: "#111827",
                borderRadius: 10,
                padding: 10,
                borderWidth: 1,
                borderColor: "#1F2937",
                alignItems: "center",
              }}
            >
              <Text style={{ color: s.color, fontSize: 20, fontWeight: "900" }}>
                {s.value}
              </Text>
              <Text
                style={{ color: "#4B5563", fontSize: 10, fontWeight: "600" }}
              >
                {s.label}
              </Text>
            </View>
          ))}
        </View>

        {/* Filters */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ flexGrow: 0 }}
        >
          <View style={{ flexDirection: "row", gap: 8 }}>
            {FILTERS.map((f) => (
              <TouchableOpacity
                key={f}
                onPress={() => setActiveFilter(f)}
                style={{
                  backgroundColor: activeFilter === f ? "#DC2626" : "#111827",
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 20,
                  borderWidth: 1,
                  borderColor: activeFilter === f ? "#DC2626" : "#1F2937",
                }}
              >
                <Text
                  style={{ color: "#F9FAFB", fontSize: 12, fontWeight: "700" }}
                >
                  {f}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>

      <ScrollView
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 80,
        }}
        refreshControl={
          <RefreshControl
            refreshing={isFetching}
            onRefresh={refetch}
            tintColor="#DC2626"
          />
        }
      >
        {isLoading ? (
          <View style={{ paddingTop: 60, alignItems: "center" }}>
            <ActivityIndicator color="#DC2626" size="large" />
            <Text style={{ color: "#6B7280", marginTop: 12 }}>
              Loading history...
            </Text>
          </View>
        ) : filtered.length === 0 ? (
          <View style={{ paddingTop: 60, alignItems: "center" }}>
            <AlertTriangle size={48} color="#374151" />
            <Text
              style={{
                color: "#6B7280",
                marginTop: 14,
                fontSize: 15,
                fontWeight: "600",
              }}
            >
              No incidents found
            </Text>
            <Text
              style={{
                color: "#4B5563",
                marginTop: 6,
                fontSize: 12,
                textAlign: "center",
              }}
            >
              Your emergency history will appear here after your first SOS alert
            </Text>
          </View>
        ) : (
          filtered.map((item, i) => (
            <IncidentCard key={`${item.id}-${item.type}-${i}`} item={item} />
          ))
        )}
      </ScrollView>
    </View>
  );
}
