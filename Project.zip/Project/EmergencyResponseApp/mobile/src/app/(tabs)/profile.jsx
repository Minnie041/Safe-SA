import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import KeyboardAvoidingAnimatedView from "@/components/KeyboardAvoidingAnimatedView";
import {
  Menu,
  User,
  Droplets,
  AlertCircle,
  Mail,
  Save,
  Heart,
  Pill,
  Phone,
  Shield,
  CheckCircle,
} from "lucide-react-native";
import { useUser } from "@/utils/auth/useUser";
import { useAuth } from "@/utils/auth/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useDrawer } from "@/utils/DrawerContext";

const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

function FieldLabel({ icon: Icon, label, color = "#9CA3AF" }) {
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 6,
        marginBottom: 6,
      }}
    >
      <Icon size={13} color={color} />
      <Text
        style={{
          color: "#9CA3AF",
          fontSize: 11,
          fontWeight: "700",
          letterSpacing: 0.5,
        }}
      >
        {label.toUpperCase()}
      </Text>
    </View>
  );
}

function StyledInput({
  value,
  onChangeText,
  placeholder,
  multiline,
  keyboardType,
}) {
  return (
    <TextInput
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor="#4B5563"
      multiline={multiline}
      keyboardType={keyboardType || "default"}
      numberOfLines={multiline ? 3 : 1}
      style={{
        backgroundColor: "#111827",
        borderWidth: 1,
        borderColor: "#1F2937",
        borderRadius: 10,
        padding: 12,
        fontSize: 14,
        color: "#F9FAFB",
        textAlignVertical: multiline ? "top" : "center",
        minHeight: multiline ? 72 : undefined,
      }}
    />
  );
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const { isAuthenticated, signIn } = useAuth();
  const { openDrawer } = useDrawer();
  const queryClient = useQueryClient();
  const [saved, setSaved] = useState(false);

  const { data: profile, isLoading } = useQuery({
    queryKey: ["emergencyProfile", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const res = await fetch(`/api/emergency/profile?userId=${user.id}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user?.id,
  });

  const [form, setForm] = useState({
    fullName: "",
    phoneNumber: "",
    bloodType: "",
    allergies: "",
    medications: "",
    conditions: "",
    guardianEmail: "",
  });

  useEffect(() => {
    if (profile) {
      setForm({
        fullName: profile.full_name || "",
        phoneNumber: profile.phone_number || "",
        bloodType: profile.blood_type || "",
        allergies: profile.allergies || "",
        medications: profile.medications || "",
        conditions: profile.conditions || "",
        guardianEmail: profile.guardian_email || "",
      });
    }
  }, [profile]);

  const mutation = useMutation({
    mutationFn: async (data) => {
      const res = await fetch("/api/emergency/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user?.id || "anonymous", ...data }),
      });
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["emergencyProfile"]);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
    onError: () =>
      Alert.alert("Error", "Could not save profile. Please try again."),
  });

  if (!isAuthenticated) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#0A0F1E",
          alignItems: "center",
          justifyContent: "center",
          padding: 32,
        }}
      >
        <Shield size={48} color="#DC2626" />
        <Text
          style={{
            color: "#F9FAFB",
            fontSize: 20,
            fontWeight: "800",
            marginTop: 16,
            textAlign: "center",
          }}
        >
          Medical Profile
        </Text>
        <Text
          style={{
            color: "#6B7280",
            fontSize: 14,
            textAlign: "center",
            marginTop: 8,
          }}
        >
          Sign in to manage your emergency medical profile
        </Text>
        <TouchableOpacity
          onPress={signIn}
          style={{
            marginTop: 24,
            backgroundColor: "#DC2626",
            paddingHorizontal: 32,
            paddingVertical: 14,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}>
            Sign In
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  const initials =
    user?.name
      ?.split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2) || "U";

  return (
    <View style={{ flex: 1, backgroundColor: "#0A0F1E" }}>
      <KeyboardAvoidingAnimatedView behavior="padding" style={{ flex: 1 }}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
        >
          {/* Header */}
          <View
            style={{
              paddingTop: insets.top + 8,
              paddingHorizontal: 20,
              paddingBottom: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 20,
              }}
            >
              <TouchableOpacity
                onPress={openDrawer}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 10,
                  backgroundColor: "#111827",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Menu size={20} color="#9CA3AF" />
              </TouchableOpacity>
              <Text
                style={{ color: "#F9FAFB", fontWeight: "800", fontSize: 18 }}
              >
                Medical Profile
              </Text>
              <View style={{ width: 40 }} />
            </View>

            {/* Avatar */}
            <View style={{ alignItems: "center", marginBottom: 20 }}>
              <View
                style={{
                  width: 72,
                  height: 72,
                  borderRadius: 36,
                  backgroundColor: "#DC2626",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 10,
                }}
              >
                <Text
                  style={{ color: "#fff", fontSize: 28, fontWeight: "900" }}
                >
                  {initials}
                </Text>
              </View>
              <Text
                style={{ color: "#F9FAFB", fontWeight: "800", fontSize: 18 }}
              >
                {user?.name || "SafeSA User"}
              </Text>
              <Text style={{ color: "#6B7280", fontSize: 12, marginTop: 2 }}>
                {user?.email}
              </Text>
              {profile?.popia_accepted_at && (
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 5,
                    marginTop: 8,
                    backgroundColor: "#064E3B",
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 20,
                  }}
                >
                  <CheckCircle size={12} color="#34D399" />
                  <Text
                    style={{
                      color: "#34D399",
                      fontSize: 11,
                      fontWeight: "700",
                    }}
                  >
                    POPIA Compliant ·{" "}
                    {new Date(profile.popia_accepted_at).toLocaleDateString(
                      "en-ZA",
                    )}
                  </Text>
                </View>
              )}
            </View>
          </View>

          {/* Form */}
          <View style={{ paddingHorizontal: 20, gap: 16 }}>
            {/* Personal */}
            <View
              style={{
                backgroundColor: "#111827",
                borderRadius: 16,
                padding: 16,
                borderWidth: 1,
                borderColor: "#1F2937",
              }}
            >
              <Text
                style={{
                  color: "#9CA3AF",
                  fontSize: 10,
                  fontWeight: "800",
                  letterSpacing: 1,
                  marginBottom: 16,
                }}
              >
                PERSONAL INFORMATION
              </Text>
              <View style={{ gap: 14 }}>
                <View>
                  <FieldLabel icon={User} label="Full Name" />
                  <StyledInput
                    value={form.fullName}
                    onChangeText={(v) =>
                      setForm((p) => ({ ...p, fullName: v }))
                    }
                    placeholder="John Dlamini"
                  />
                </View>
                <View>
                  <FieldLabel icon={Phone} label="Phone Number" />
                  <StyledInput
                    value={form.phoneNumber}
                    onChangeText={(v) =>
                      setForm((p) => ({ ...p, phoneNumber: v }))
                    }
                    placeholder="+27 82 000 0000"
                    keyboardType="phone-pad"
                  />
                </View>
                <View>
                  <FieldLabel
                    icon={Mail}
                    label="Guardian Email"
                    color="#2563EB"
                  />
                  <StyledInput
                    value={form.guardianEmail}
                    onChangeText={(v) =>
                      setForm((p) => ({ ...p, guardianEmail: v }))
                    }
                    placeholder="guardian@example.com"
                    keyboardType="email-address"
                  />
                </View>
              </View>
            </View>

            {/* Medical */}
            <View
              style={{
                backgroundColor: "#111827",
                borderRadius: 16,
                padding: 16,
                borderWidth: 1,
                borderColor: "#1F2937",
              }}
            >
              <Text
                style={{
                  color: "#9CA3AF",
                  fontSize: 10,
                  fontWeight: "800",
                  letterSpacing: 1,
                  marginBottom: 16,
                }}
              >
                MEDICAL INFORMATION
              </Text>

              <View style={{ marginBottom: 14 }}>
                <FieldLabel
                  icon={Droplets}
                  label="Blood Type"
                  color="#DC2626"
                />
                <View
                  style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}
                >
                  {BLOOD_TYPES.map((bt) => (
                    <TouchableOpacity
                      key={bt}
                      onPress={() => setForm((p) => ({ ...p, bloodType: bt }))}
                      style={{
                        paddingHorizontal: 14,
                        paddingVertical: 8,
                        borderRadius: 8,
                        borderWidth: 1.5,
                        borderColor:
                          form.bloodType === bt ? "#DC2626" : "#1F2937",
                        backgroundColor:
                          form.bloodType === bt ? "#450A0A" : "#0A0F1E",
                      }}
                    >
                      <Text
                        style={{
                          color: form.bloodType === bt ? "#F87171" : "#6B7280",
                          fontWeight: "800",
                          fontSize: 13,
                        }}
                      >
                        {bt}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={{ gap: 14 }}>
                <View>
                  <FieldLabel
                    icon={AlertCircle}
                    label="Allergies"
                    color="#F59E0B"
                  />
                  <StyledInput
                    value={form.allergies}
                    onChangeText={(v) =>
                      setForm((p) => ({ ...p, allergies: v }))
                    }
                    placeholder="e.g. Penicillin, Peanuts, Latex..."
                    multiline
                  />
                </View>
                <View>
                  <FieldLabel
                    icon={Pill}
                    label="Current Medications"
                    color="#8B5CF6"
                  />
                  <StyledInput
                    value={form.medications}
                    onChangeText={(v) =>
                      setForm((p) => ({ ...p, medications: v }))
                    }
                    placeholder="e.g. Metformin 500mg, Aspirin..."
                    multiline
                  />
                </View>
                <View>
                  <FieldLabel
                    icon={Heart}
                    label="Chronic Conditions"
                    color="#EC4899"
                  />
                  <StyledInput
                    value={form.conditions}
                    onChangeText={(v) =>
                      setForm((p) => ({ ...p, conditions: v }))
                    }
                    placeholder="e.g. Diabetes, Hypertension, Asthma..."
                    multiline
                  />
                </View>
              </View>
            </View>

            {/* Save */}
            <TouchableOpacity
              onPress={() => mutation.mutate(form)}
              disabled={mutation.isPending}
              style={{
                backgroundColor: saved ? "#059669" : "#DC2626",
                borderRadius: 14,
                padding: 16,
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                gap: 10,
              }}
            >
              {mutation.isPending ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : saved ? (
                <>
                  <CheckCircle size={18} color="#fff" />
                  <Text
                    style={{ color: "#fff", fontSize: 15, fontWeight: "800" }}
                  >
                    Profile Saved!
                  </Text>
                </>
              ) : (
                <>
                  <Save size={18} color="#fff" />
                  <Text
                    style={{ color: "#fff", fontSize: 15, fontWeight: "800" }}
                  >
                    Save Medical Profile
                  </Text>
                </>
              )}
            </TouchableOpacity>

            {/* POPIA Card */}
            <View
              style={{
                backgroundColor: "#0D1A0D",
                borderRadius: 14,
                padding: 16,
                borderWidth: 1,
                borderColor: "#1A3A1A",
                marginBottom: 8,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 8,
                  marginBottom: 8,
                }}
              >
                <Shield size={16} color="#34D399" />
                <Text
                  style={{ color: "#34D399", fontWeight: "800", fontSize: 12 }}
                >
                  POPIA DATA PROTECTION
                </Text>
              </View>
              <Text style={{ color: "#6B7280", fontSize: 12, lineHeight: 18 }}>
                Your medical data is encrypted and only shared with registered
                guardians during active SOS emergencies. You may request
                deletion at any time.
              </Text>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingAnimatedView>
    </View>
  );
}
