import {
  createContext,
  useContext,
  useRef,
  useState,
  useCallback,
} from "react";
import { Animated, Dimensions } from "react-native";

const DRAWER_WIDTH = Dimensions.get("window").width * 0.82;
const DrawerContext = createContext(null);

export function DrawerProvider({ children }) {
  const [isOpen, setIsOpen] = useState(false);
  const translateX = useRef(new Animated.Value(-DRAWER_WIDTH)).current;

  const openDrawer = useCallback(() => {
    setIsOpen(true);
    Animated.spring(translateX, {
      toValue: 0,
      useNativeDriver: true,
      tension: 65,
      friction: 11,
    }).start();
  }, [translateX]);

  const closeDrawer = useCallback(() => {
    Animated.spring(translateX, {
      toValue: -DRAWER_WIDTH,
      useNativeDriver: true,
      tension: 65,
      friction: 11,
    }).start(() => setIsOpen(false));
  }, [translateX]);

  return (
    <DrawerContext.Provider
      value={{ isOpen, openDrawer, closeDrawer, translateX, DRAWER_WIDTH }}
    >
      {children}
    </DrawerContext.Provider>
  );
}

export function useDrawer() {
  const ctx = useContext(DrawerContext);
  if (!ctx) throw new Error("useDrawer must be used within DrawerProvider");
  return ctx;
}
