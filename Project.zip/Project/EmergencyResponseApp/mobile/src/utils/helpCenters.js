export const HELP_CENTERS = [
  {
    id: "hosp_central",
    name: "Addington Hospital (Durban)",
    type: "Hospital",
    latitude: -29.8604, 
    longitude: 31.0415,
    apiKey: "admin_secret_123" 
  },
  {
    id: "fire_station_5",
    name: "Durban Central Fire",
    type: "Fire",
    latitude: -29.8587,
    longitude: 31.0180,
    apiKey: "admin_secret_456"
  }
];