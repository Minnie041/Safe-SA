import { HELP_CENTERS } from './helpCenters';

export function getNearestHelpCenter(userLat, userLon) {
  return HELP_CENTERS.reduce((prev, curr) => {
    const prevDist = Math.sqrt(Math.pow(userLat - prev.latitude, 2) + Math.pow(userLon - prev.longitude, 2));
    const currDist = Math.sqrt(Math.pow(userLat - curr.latitude, 2) + Math.pow(userLon - curr.longitude, 2));
    return (currDist < prevDist) ? curr : prev;
  });
}