// 1. YOUR HARDCODED ADMINISTRATORS (Help Centers)
// You can add more hospitals, police stations, or fire stations here.
// The app will automatically route the SOS to whichever one is closest to the user.
export const HELP_CENTERS = [
  {
    id: "hosp_central_001",
    name: "Central Hospital",
    type: "Hospital",
    latitude: -26.1234, // Put real Lat/Lon here
    longitude: 28.1234,
    adminKey: "HOSP123" // The hardcoded login key
  },
  {
    id: "police_west_001",
    name: "West End Police",
    type: "Police",
    latitude: -26.1900,
    longitude: 28.1500,
    adminKey: "POLICE456"
  },
  {
    id: "fire_station_east",
    name: "East Side Fire",
    type: "Fire",
    latitude: -26.1000,
    longitude: 28.2000,
    adminKey: "FIRE789"
  }
];

// 2. THE CALCULATION LOGIC (Haversine Formula)
// This calculates the distance between two GPS points in kilometers
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the earth in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; 
  return distance;
}

// 3. THE FINDER FUNCTION
// This is what your SOS button will call
export function findNearestAdmin(userLat, userLon) {
  let nearest = null;
  let minDistance = Infinity;

  HELP_CENTERS.forEach((center) => {
    const dist = calculateDistance(userLat, userLon, center.latitude, center.longitude);
    if (dist < minDistance) {
      minDistance = dist;
      nearest = center;
    }
  });

  return nearest; // Returns the closest help center object
}