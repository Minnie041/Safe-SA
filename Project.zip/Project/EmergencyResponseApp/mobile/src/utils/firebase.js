// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDE3Co_NnykkHsrt_wCvOV81AkcQ2ezuZs",
  authDomain: "emergencyresponseapp-2e0e7.firebaseapp.com",
  projectId: "emergencyresponseapp-2e0e7",
  storageBucket: "emergencyresponseapp-2e0e7.firebasestorage.app",
  messagingSenderId: "184303009689",
  appId: "1:184303009689:web:18cd4365fa653823205d08"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);