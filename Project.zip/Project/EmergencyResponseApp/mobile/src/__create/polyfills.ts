// 1. Keep a copy of the original fetch to prevent the infinite loop
const originalFetch = global.fetch;

import updatedFetch from './fetch';

// 2. Override the global fetch safely
// @ts-ignore
global.fetch = function (input: any, init?: any) {
    // We use the updatedFetch but ensure it doesn't crash the stack
    return updatedFetch(input, init);
};