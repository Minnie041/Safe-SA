import { useEffect, useState } from "react";
import useUser from "@/utils/useUser";

export default function OnboardingPage() {
  const { data: user, loading: userLoading } = useUser();
  const [status, setStatus] = useState("Initializing...");

  useEffect(() => {
    const completeOnboarding = async () => {
      if (userLoading || !user) return;
      try {
        const hasAcceptedPopia =
          localStorage.getItem("pendingPopia") === "true";
        if (hasAcceptedPopia) {
          setStatus("Setting up your secure profile...");
          const fullName =
            localStorage.getItem("pendingFullName") || user.name || null;
          const phone = localStorage.getItem("pendingPhone") || null;
          const res = await fetch("/api/emergency/profile", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              userId: user.id,
              fullName,
              phoneNumber: phone,
              popiaAccepted: true,
            }),
          });
          if (res.ok) {
            localStorage.removeItem("pendingPopia");
            localStorage.removeItem("pendingFullName");
            localStorage.removeItem("pendingPhone");
            setStatus("Profile secured! Redirecting...");
            window.location.href = "/api/auth/expo-web-success";
          } else {
            setStatus("Failed to finalize profile. Please contact support.");
          }
        } else {
          window.location.href = "/api/auth/expo-web-success";
        }
      } catch (err) {
        console.error(err);
        setStatus("An error occurred during setup.");
      }
    };
    completeOnboarding();
  }, [user, userLoading]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0A0F1E] font-['Inter']">
      <div className="text-center">
        <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#DC2626] mx-auto">
          <span className="text-3xl font-black text-white">S</span>
        </div>
        <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-[#DC2626] border-t-transparent mx-auto"></div>
        <p className="text-sm font-semibold text-white">{status}</p>
        <p className="mt-1 text-xs text-[#6B7280]">SafeSA Emergency Response</p>
      </div>
    </div>
  );
}
