import useAuth from "@/utils/useAuth";

export default function LogoutPage() {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F9FAFB] font-['Inter']">
      <div className="w-full max-w-sm rounded-xl border border-[#E5E7EB] bg-white p-8 text-center">
        <h1 className="mb-4 text-xl font-semibold text-[#111827]">Sign Out</h1>
        <p className="mb-8 text-sm text-[#6B7280]">
          Are you sure you want to sign out of SafeSA?
        </p>
        <button
          onClick={handleSignOut}
          className="w-full rounded-lg bg-[#2563EB] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]"
        >
          Confirm Sign Out
        </button>
      </div>
    </div>
  );
}
