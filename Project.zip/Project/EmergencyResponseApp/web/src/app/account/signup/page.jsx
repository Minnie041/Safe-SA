import { useState } from "react";
import useAuth from "@/utils/useAuth";

export default function SignUpPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [popiaAccepted, setPopiaAccepted] = useState(false);

  const { signUpWithCredentials } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!fullName || !email || !password || !confirmPassword) {
      setError("Please fill in all required fields");
      setLoading(false);
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      setLoading(false);
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters");
      setLoading(false);
      return;
    }
    if (!popiaAccepted) {
      setError("You must accept the POPIA agreement to continue");
      setLoading(false);
      return;
    }

    try {
      localStorage.setItem("pendingPopia", "true");
      localStorage.setItem("pendingFullName", fullName);
      localStorage.setItem("pendingPhone", phone);
      await signUpWithCredentials({
        email,
        password,
        callbackUrl: "/onboarding",
        redirect: true,
      });
    } catch (err) {
      setError("Something went wrong. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-[#F9FAFB] p-4 font-['Inter']">
      <form
        noValidate
        onSubmit={onSubmit}
        className="w-full max-w-md rounded-xl border border-[#E5E7EB] bg-white p-8 shadow-sm"
      >
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#DC2626]">
            <span className="text-lg font-black text-white">S</span>
          </div>
          <div>
            <h1 className="text-xl font-bold text-[#111827]">
              Create SafeSA Account
            </h1>
            <p className="text-xs text-[#6B7280]">
              Emergency response network · South Africa
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#374151]">
                Full Name *
              </label>
              <input
                required
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="John Dlamini"
                className="w-full rounded-lg border border-[#E5E7EB] px-3 py-2 text-sm outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#374151]">
                Phone Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+27 82 000 0000"
                className="w-full rounded-lg border border-[#E5E7EB] px-3 py-2 text-sm outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#374151]">
              Email Address *
            </label>
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full rounded-lg border border-[#E5E7EB] px-3 py-2 text-sm outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#374151]">
                Password *
              </label>
              <input
                required
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min. 8 characters"
                className="w-full rounded-lg border border-[#E5E7EB] px-3 py-2 text-sm outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#374151]">
                Confirm Password *
              </label>
              <input
                required
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Repeat password"
                className="w-full rounded-lg border border-[#E5E7EB] px-3 py-2 text-sm outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
              />
            </div>
          </div>

          {/* POPIA Section */}
          <div className="rounded-lg border border-[#FEF3C7] bg-[#FFFBEB] p-4">
            <p className="mb-2 text-xs font-bold text-[#92400E] uppercase tracking-wide">
              POPIA Compliance Required
            </p>
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="popia"
                checked={popiaAccepted}
                onChange={(e) => setPopiaAccepted(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-[#D97706] text-[#D97706] focus:ring-[#D97706]"
              />
              <label
                htmlFor="popia"
                className="text-xs text-[#78350F] leading-relaxed"
              >
                I accept the{" "}
                <span className="font-bold">
                  Protection of Personal Information Act (POPIA)
                </span>
                . I consent to the collection and processing of my personal
                data, medical information, and GPS location for emergency
                response purposes. I understand my data will be shared with
                registered guardians during emergencies.
              </label>
            </div>
          </div>

          {error && (
            <div className="rounded-lg bg-red-50 border border-red-100 p-3 text-xs text-red-700 font-medium">
              ⚠ {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !popiaAccepted}
            className="w-full rounded-lg bg-[#DC2626] px-4 py-3 text-sm font-bold text-white transition-all hover:bg-[#B91C1C] disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {loading ? "Creating account..." : "🛡️ Create SafeSA Account"}
          </button>

          <p className="text-center text-xs text-[#6B7280]">
            Already have an account?{" "}
            <a
              href="/account/signin"
              className="font-semibold text-[#2563EB] hover:underline"
            >
              Sign in
            </a>
          </p>
        </div>
      </form>
    </div>
  );
}
