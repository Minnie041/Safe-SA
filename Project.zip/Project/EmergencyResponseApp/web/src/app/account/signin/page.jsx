import { useState } from "react";
import useAuth from "@/utils/useAuth";

export default function SignInPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { signInWithCredentials } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    if (!email || !password) {
      setError("Please fill in all fields");
      setLoading(false);
      return;
    }
    try {
      await signInWithCredentials({
        email,
        password,
        callbackUrl: "/api/auth/expo-web-success",
        redirect: true,
      });
    } catch (err) {
      setError("Invalid email or password. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-[#0A0F1E] p-4 font-['Inter']">
      <form
        noValidate
        onSubmit={onSubmit}
        className="w-full max-w-sm rounded-2xl border border-[#1F2937] bg-[#111827] p-8 shadow-2xl"
      >
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#DC2626]">
            <span className="text-2xl font-black text-white">S</span>
          </div>
          <h1 className="text-2xl font-black text-white">SafeSA</h1>
          <p className="mt-1 text-sm text-[#6B7280]">
            Emergency Response Network
          </p>
        </div>

        <div className="space-y-5">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wide text-[#9CA3AF]">
              Email Address
            </label>
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full rounded-xl border border-[#1F2937] bg-[#0A0F1E] px-4 py-3 text-sm text-white outline-none placeholder:text-[#4B5563] focus:border-[#DC2626] focus:ring-1 focus:ring-[#DC2626]"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wide text-[#9CA3AF]">
              Password
            </label>
            <input
              required
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-xl border border-[#1F2937] bg-[#0A0F1E] px-4 py-3 text-sm text-white outline-none placeholder:text-[#4B5563] focus:border-[#DC2626] focus:ring-1 focus:ring-[#DC2626]"
            />
          </div>

          {error && (
            <div className="rounded-xl border border-red-900 bg-[#1A0505] px-4 py-3 text-xs font-medium text-red-400">
              ⚠ {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-[#DC2626] px-4 py-3 text-sm font-bold text-white transition-all hover:bg-[#B91C1C] disabled:opacity-50"
          >
            {loading ? "Signing in..." : "🛡️ Sign In to SafeSA"}
          </button>

          <p className="text-center text-xs text-[#6B7280]">
            No account?{" "}
            <a
              href="/account/signup"
              className="font-semibold text-[#DC2626] hover:underline"
            >
              Register for SafeSA
            </a>
          </p>
        </div>

        <div className="mt-6 border-t border-[#1F2937] pt-4 text-center">
          <p className="text-xs text-[#4B5563]">
            🔒 Protected under POPIA · South Africa
          </p>
        </div>
      </form>
    </div>
  );
}
