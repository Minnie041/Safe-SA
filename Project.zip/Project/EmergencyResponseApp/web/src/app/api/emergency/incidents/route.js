import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId");
  const limit = parseInt(searchParams.get("limit") || "50");
  if (!userId)
    return Response.json({ error: "userId required" }, { status: 400 });
  try {
    // Combine SOS alerts and incidents for full history
    const [incidents, sosAlerts] = await sql.transaction([
      sql`SELECT id, user_id, type, latitude, longitude, address, description, risk_level, risk_score, status, created_at, resolved_at FROM incidents WHERE user_id = ${userId} ORDER BY created_at DESC LIMIT ${limit}`,
      sql`SELECT id, user_id, 'sos' as type, latitude, longitude, null as address, null as description, 'high' as risk_level, 85 as risk_score, status, created_at, null as resolved_at FROM sos_alerts WHERE user_id = ${userId} ORDER BY created_at DESC LIMIT ${limit}`,
    ]);
    // Merge and sort by date
    const all = [...incidents, ...sosAlerts]
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, limit);
    return Response.json(all);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to fetch incidents" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const {
      userId,
      type,
      latitude,
      longitude,
      address,
      description,
      riskLevel,
      riskScore,
    } = await request.json();
    if (!userId || !type) {
      return Response.json(
        { error: "userId and type are required" },
        { status: 400 },
      );
    }
    const incident = await sql`
      INSERT INTO incidents (user_id, type, latitude, longitude, address, description, risk_level, risk_score)
      VALUES (${userId}, ${type}, ${latitude || null}, ${longitude || null}, ${address || null}, ${description || null}, ${riskLevel || "medium"}, ${riskScore || 50})
      RETURNING *
    `;
    return Response.json({ success: true, incident: incident[0] });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to create incident" },
      { status: 500 },
    );
  }
}

export async function PATCH(request) {
  try {
    const { id, userId, status } = await request.json();
    if (!id || !userId)
      return Response.json(
        { error: "id and userId required" },
        { status: 400 },
      );
    const resolvedAt = status === "resolved" ? new Date().toISOString() : null;
    const updated = await sql`
      UPDATE incidents SET status = ${status}, resolved_at = ${resolvedAt}
      WHERE id = ${id} AND user_id = ${userId}
      RETURNING *
    `;
    return Response.json({ success: true, incident: updated[0] });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to update incident" },
      { status: 500 },
    );
  }
}
