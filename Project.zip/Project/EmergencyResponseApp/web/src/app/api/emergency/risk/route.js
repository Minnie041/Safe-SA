import sql from "@/app/api/utils/sql";

// Simple AI-style risk assessment based on location history and time
function calculateRiskScore(incidentCount, timeOfDay, dayOfWeek) {
  let score = 20; // baseline low

  // Incident history weight
  if (incidentCount >= 10) score += 50;
  else if (incidentCount >= 5) score += 35;
  else if (incidentCount >= 2) score += 20;
  else if (incidentCount >= 1) score += 10;

  // Time of day risk (night hours are higher risk)
  const hour = timeOfDay;
  if (hour >= 22 || hour < 5)
    score += 25; // Night: high
  else if (hour >= 5 && hour < 7)
    score += 10; // Early morning
  else if (hour >= 17 && hour < 22) score += 12; // Evening

  // Weekend risk
  if (dayOfWeek === 0 || dayOfWeek === 6) score += 8;

  // Cap at 100
  score = Math.min(score, 100);

  let level = "low";
  if (score >= 70) level = "high";
  else if (score >= 40) level = "medium";

  return { score, level };
}

function getAdvice(level) {
  if (level === "high")
    return [
      "Stay in well-lit, populated areas",
      "Avoid walking alone at night",
      "Keep emergency contacts ready",
      "Share location with your guardian now",
    ];
  if (level === "medium")
    return [
      "Stay aware of your surroundings",
      "Keep your phone charged",
      "Inform someone of your whereabouts",
    ];
  return [
    "Area appears safe, stay alert",
    "Routine safety precautions advised",
  ];
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId");
  const latitude = parseFloat(searchParams.get("latitude") || "0");
  const longitude = parseFloat(searchParams.get("longitude") || "0");

  if (!userId)
    return Response.json({ error: "userId required" }, { status: 400 });

  try {
    // Count incidents near this location (within ~5km using lat/lng degree approximation)
    const radiusDeg = 0.045; // ~5km
    let nearbyCount = 0;
    try {
      const nearby = await sql`
        SELECT COUNT(*) as cnt FROM incidents
        WHERE user_id = ${userId}
        AND latitude BETWEEN ${latitude - radiusDeg} AND ${latitude + radiusDeg}
        AND longitude BETWEEN ${longitude - radiusDeg} AND ${longitude + radiusDeg}
        AND created_at > NOW() - INTERVAL '30 days'
      `;
      nearbyCount = parseInt(nearby[0]?.cnt || 0);
    } catch (e) {
      // If incidents table not ready, fallback to sos_alerts
      const sosNearby = await sql`
        SELECT COUNT(*) as cnt FROM sos_alerts
        WHERE user_id = ${userId}
        AND latitude BETWEEN ${latitude - radiusDeg} AND ${latitude + radiusDeg}
        AND longitude BETWEEN ${longitude - radiusDeg} AND ${longitude + radiusDeg}
        AND created_at > NOW() - INTERVAL '30 days'
      `;
      nearbyCount = parseInt(sosNearby[0]?.cnt || 0);
    }

    const now = new Date();
    const { score, level } = calculateRiskScore(
      nearbyCount,
      now.getHours(),
      now.getDay(),
    );

    return Response.json({
      riskScore: score,
      riskLevel: level,
      nearbyIncidents: nearbyCount,
      advice: getAdvice(level),
      analyzedAt: now.toISOString(),
    });
  } catch (error) {
    console.error(error);
    // Return a default assessment if DB fails
    return Response.json({
      riskScore: 25,
      riskLevel: "low",
      nearbyIncidents: 0,
      advice: ["Stay aware of your surroundings"],
      analyzedAt: new Date().toISOString(),
    });
  }
}
