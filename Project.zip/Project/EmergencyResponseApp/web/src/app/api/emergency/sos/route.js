import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId");
  if (!userId)
    return Response.json({ error: "userId is required" }, { status: 400 });
  try {
    const alerts = await sql`
      SELECT * FROM sos_alerts WHERE user_id = ${userId} ORDER BY created_at DESC
    `;
    return Response.json(alerts);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to fetch alerts" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { userId, latitude, longitude, address, riskLevel, riskScore } =
      await request.json();
    if (!userId || !latitude || !longitude) {
      return Response.json(
        { error: "userId, latitude, and longitude are required" },
        { status: 400 },
      );
    }

    // 1. Store the SOS alert
    const alert = await sql`
      INSERT INTO sos_alerts (user_id, latitude, longitude, status)
      VALUES (${userId}, ${latitude}, ${longitude}, 'active')
      RETURNING *
    `;

    // 2. Also store in incidents table for unified history
    try {
      await sql`
        INSERT INTO incidents (user_id, type, latitude, longitude, address, risk_level, risk_score, status)
        VALUES (${userId}, 'sos', ${latitude}, ${longitude}, ${address || null}, ${riskLevel || "high"}, ${riskScore || 85}, 'active')
      `;
    } catch (e) {
      // Non-critical, continue
    }

    // 3. Fetch all guardians and profile for notification
    const [profile, guardians] = await sql.transaction([
      sql`SELECT guardian_email, full_name, blood_type, allergies, medications, conditions FROM emergency_profiles WHERE user_id = ${userId}`,
      sql`SELECT name, email, phone FROM guardians WHERE user_id = ${userId}`,
    ]);

    const fullName = profile[0]?.full_name || "SafeSA User";
    const mapsLink = `https://maps.google.com/?q=${latitude},${longitude}`;
    const timestamp = new Date().toLocaleString("en-ZA", {
      timeZone: "Africa/Johannesburg",
    });

    // 4. Build email content for guardians
    const medicalInfo = [
      profile[0]?.blood_type ? `Blood Type: ${profile[0].blood_type}` : null,
      profile[0]?.allergies ? `Allergies: ${profile[0].allergies}` : null,
      profile[0]?.medications ? `Medications: ${profile[0].medications}` : null,
      profile[0]?.conditions ? `Conditions: ${profile[0].conditions}` : null,
    ]
      .filter(Boolean)
      .join("\n");

    const emailRecipients = [
      ...(profile[0]?.guardian_email
        ? [{ email: profile[0].guardian_email, name: "Guardian" }]
        : []),
      ...guardians
        .filter((g) => g.email)
        .map((g) => ({ email: g.email, name: g.name })),
    ];

    for (const recipient of emailRecipients) {
      console.log(
        `[🚨 SOS ALERT] Sending emergency notification to ${recipient.name} (${recipient.email})`,
      );
      console.log(`User: ${fullName}`);
      console.log(`Location: ${mapsLink}`);
      console.log(`Risk Level: ${riskLevel || "HIGH"}`);
      console.log(`Timestamp: ${timestamp}`);
      console.log(`Medical Info:\n${medicalInfo || "Not provided"}`);
      // Production: integrate Resend/SendGrid here
    }

    // 5. Update location share
    try {
      await sql`
        INSERT INTO location_shares (user_id, latitude, longitude, is_active)
        VALUES (${userId}, ${latitude}, ${longitude}, true)
        ON CONFLICT DO NOTHING
      `;
    } catch (e) {}

    return Response.json({
      success: true,
      alert: alert[0],
      notified: emailRecipients.length,
      mapsLink,
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to trigger SOS" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const { alertId, userId, status } = await request.json();
    const updated = await sql`
      UPDATE sos_alerts SET status = ${status} WHERE id = ${alertId} AND user_id = ${userId} RETURNING *
    `;
    return Response.json({ success: true, alert: updated[0] });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to update alert" }, { status: 500 });
  }
}
