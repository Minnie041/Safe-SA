import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId");
  if (!userId)
    return Response.json({ error: "userId required" }, { status: 400 });
  try {
    const guardians = await sql`
      SELECT * FROM guardians WHERE user_id = ${userId} ORDER BY created_at ASC
    `;
    return Response.json(guardians);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to fetch guardians" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const { userId, name, phone, email, relationship } = await request.json();
    if (!userId || !name || !phone) {
      return Response.json(
        { error: "userId, name, and phone are required" },
        { status: 400 },
      );
    }
    const guardian = await sql`
      INSERT INTO guardians (user_id, name, phone, email, relationship)
      VALUES (${userId}, ${name}, ${phone}, ${email || null}, ${relationship || null})
      RETURNING *
    `;
    return Response.json({ success: true, guardian: guardian[0] });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to add guardian" }, { status: 500 });
  }
}

export async function DELETE(request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  const userId = searchParams.get("userId");
  if (!id || !userId)
    return Response.json({ error: "id and userId required" }, { status: 400 });
  try {
    await sql`DELETE FROM guardians WHERE id = ${id} AND user_id = ${userId}`;
    return Response.json({ success: true });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to delete guardian" },
      { status: 500 },
    );
  }
}
