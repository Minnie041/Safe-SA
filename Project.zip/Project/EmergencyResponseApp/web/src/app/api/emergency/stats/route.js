import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId");
  if (!userId)
    return Response.json({ error: "userId required" }, { status: 400 });

  try {
    const [incidentStats, guardianCount, sosStats] = await sql.transaction([
      sql`SELECT COUNT(*) as total FROM incidents WHERE user_id = ${userId}`,
      sql`SELECT COUNT(*) as total FROM guardians WHERE user_id = ${userId}`,
      sql`SELECT COUNT(*) as total FROM sos_alerts WHERE user_id = ${userId}`,
    ]);

    const totalIncidents =
      parseInt(incidentStats[0]?.total || 0) +
      parseInt(sosStats[0]?.total || 0);
    const totalGuardians = parseInt(guardianCount[0]?.total || 0);

    return Response.json({
      totalIncidents,
      totalGuardians,
      totalSosAlerts: parseInt(sosStats[0]?.total || 0),
    });
  } catch (error) {
    console.error(error);
    return Response.json({
      totalIncidents: 0,
      totalGuardians: 0,
      totalSosAlerts: 0,
    });
  }
}
