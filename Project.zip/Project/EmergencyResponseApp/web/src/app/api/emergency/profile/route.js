import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId");

  if (!userId) {
    return Response.json({ error: "userId is required" }, { status: 400 });
  }

  try {
    const profile = await sql`
      SELECT * FROM emergency_profiles WHERE user_id = ${userId}
    `;
    return Response.json(profile[0] || null);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to fetch profile" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const {
      userId,
      fullName,
      phoneNumber,
      bloodType,
      allergies,
      medications,
      conditions,
      guardianEmail,
      popiaAccepted,
    } = await request.json();

    if (!userId) {
      return Response.json({ error: "userId is required" }, { status: 400 });
    }

    const profile = await sql`
      INSERT INTO emergency_profiles (
        user_id, full_name, phone_number, blood_type, allergies,
        medications, conditions, guardian_email, popia_accepted, popia_accepted_at, updated_at
      )
      VALUES (
        ${userId}, ${fullName || null}, ${phoneNumber || null}, ${bloodType || null},
        ${allergies || null}, ${medications || null}, ${conditions || null},
        ${guardianEmail || null}, ${popiaAccepted === true},
        ${popiaAccepted === true ? new Date().toISOString() : null},
        NOW()
      )
      ON CONFLICT (user_id) DO UPDATE SET
        full_name = COALESCE(EXCLUDED.full_name, emergency_profiles.full_name),
        phone_number = COALESCE(EXCLUDED.phone_number, emergency_profiles.phone_number),
        blood_type = COALESCE(EXCLUDED.blood_type, emergency_profiles.blood_type),
        allergies = COALESCE(EXCLUDED.allergies, emergency_profiles.allergies),
        medications = COALESCE(EXCLUDED.medications, emergency_profiles.medications),
        conditions = COALESCE(EXCLUDED.conditions, emergency_profiles.conditions),
        guardian_email = COALESCE(EXCLUDED.guardian_email, emergency_profiles.guardian_email),
        popia_accepted = CASE WHEN EXCLUDED.popia_accepted = true THEN true ELSE emergency_profiles.popia_accepted END,
        popia_accepted_at = CASE WHEN EXCLUDED.popia_accepted = true THEN NOW() ELSE emergency_profiles.popia_accepted_at END,
        updated_at = NOW()
      RETURNING *
    `;

    return Response.json({ success: true, profile: profile[0] });
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to update profile" },
      { status: 500 },
    );
  }
}
